<!DOCTYPE html>
<html lang="nl">
{{-- AIzaSyCPns7mDksSvNSzRWdLGc6RASWjqe2FrSc old map api key --}}
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Omegabijles</title>
    <!-- Bootstrap 4 -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <!--Font Awesome-->
    <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/geocomplete/1.7.0/jquery.geocomplete.js"></script>
     <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDGQP5ZlgVr-tUIc2inBMeZgO7iZWkOuv8&libraries=places"
        type="text/javascript"></script>
      {{--   <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDGQP5ZlgVr-tUIc2inBMeZgO7iZWkOuv8&libraries=places"
        type="text/javascript"></script> --}}
    <!-- my custom style -->
    <link rel="stylesheet" href="{{ URL::to('public/frontEnd/css/style.css') }}">
</head>

<body>
    <div id="preloader">
        <div id="loader">
            <div class="md-preloader"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" height="75" width="75" viewbox="0 0 75 75"><circle cx="37.5" cy="37.5" r="33.5" stroke-width="8"/></svg></div>
        </div>
    </div>
    <div class="container-fluid">
        <header class="site_top">
            <div class="inner_bg">
                <nav class="navbar navbar-expand-md navbar_custom navbar-dark dpadding">
                    <!-- Brand -->
                    <a class="navbar-brand" href="{{ url('/') }}"><img src="{{ URL::to('public/frontEnd/img/icons/logo_w@3x.svg') }}" alt="Logo"></a>
                    <!-- Toggler/collapsibe Button -->
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <!-- Navbar links -->
                    @include('frontEnd.includes.sidebar')
                </nav>
                <div class="intro_text dpadding">
                    <h1>Vind snel en gemakkelijk de bijlesgever die bij je past</h1>
                    <h4>Krijg bijles van een (oud-)leerling die bij je past en zie dat je vooruit gaat.</h4>
                    <div class="search_box">
                    
                            <select class="selections" name="subject" id="subject">
                      {{--           <option value="Empty">Vak</option> --}}
                                <option value="Aardrijkskunde">Aardrijkskunde</option>
                                <option value="Biologie">Biologie</option>
                                <option value="Duits">Duits</option>
                                <option value="Economie">Economie</option>
                                <option value="Engels">Engels</option>
                                <option value="Filosofie">Filosofie</option>
                                <option value="Frans">Frans</option>
                                <option value="Geschiedenis">Geschiedenis</option>
                                <option value="Grieks">Grieks</option>
                                <option value="Latijn">Latijn</option>
                                <option value="Maatschappijleer">Maatschappijleer</option>
                                <option value="Natuurkunde">Natuurkunde</option>
                                <option value="Nederlands">Nederlands</option>
                                <option value="NLT">NLT</option>
                                <option value="Scheikunde">Scheikunde</option>
                                <option value="Wiskunde (onderbouw)">Wiskunde (onderbouw)</option>
                                <option value="Wiskunde A">Wiskunde A</option>
                                <option value="Wiskunde B">Wiskunde B</option>
                                <option value="Wiskunde C">Wiskunde C</option>
                            </select>
                            <input type="text" name="postcode" id="autocomplete" placeholder="Postcode  bijv ‘1011AA’">
                            <button type="submit" name="submit_btn" class="btn submit_btn" onclick="searchTutor(event)">Zoeken</button>
                     
                        <h6>Kies uit +20 bijlesgevers die jouw school kennen</h6>
                    </div>
                </div>
            </div>
        </header>
        {{-- <nav class="navbar navbar-expand-lg  navbar-dark navbar_lang">
            <ul class="navbar-nav" style="cursor:pointer">
                <li class="nav-item">
                    <a class="nav-link" onclick="setSubject('Engels')">Engels</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" onclick="setSubject('Natuurkunde')">Natuurkunde</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" onclick="setSubject('Wiskunde (onderbouw)')">Wiskunde(Onderbouw)</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" onclick="setSubject('Latijn')">Latijn</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" onclick="setSubject('Economie')">Economie</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" onclick="setSubject('Scheikunde')">Scheikunde</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" onclick="setSubject('Frans')">Frans</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" onclick="setSubject('Duits')">Duits</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" onclick="setSubject('Biologie')">Biologie</a>
                </li>
            </ul>
        </nav> --}}
        <section class="descriptive_contents">
            <div class="row">
                <div class="col-sm-6 text-center">
                    <img src="{{ URL::to('public/frontEnd/img/schermafbeelding1.png') }}" alt="Image 1">
                </div>
                <div class="col-sm-6">
                    <h2>Bekend met het x</h2>
                    <p>Al onze bijlesgevers zijn leerlingen of oud-leerlingen die bekend zijn met het Felisenum.</p>
                    <p><span><i class="fas fa-check"></i></span> We weten wat bepaalde docenten willen zien op je toetsen</p>
                    <p><span><i class="fas fa-check"></i></span> We hebben zelf precies dezelfde stof ook al een keer gehad, dus we weten waar de moeilijkheden liggen</p>
                    <p><span><i class="fas fa-check"></i></span> Jouw docent en ouders krijgen regelmatige updates van hoe het met de bijlessen gaat
                    </p>
                    <a href="#" class="underline">Hoe het werkt</a>
                </div>
            </div>
            <div class="row some_margin reverse">
                <div class="col-sm-6">
                    <h2>Geselecteerd en getraind</h2>
                    <p>Al onze bijlesgevers zijn persoonlijk geselecteerd en hebben interne training gehad. Zo weten ze precies hoe ze je nog beter bijles kunnen geven. Onze bijlesgevers:</p>
                    <p><span><i class="fas fa-check"></i></span> Hebben minimaal een 7,5 voor de vakken waar ze bijles in geven</p>
                    <p><span><i class="fas fa-check"></i></span> Weten hoe ze jou vooruit kunnen helpen in oa. motivatie, concentratie en plannen
                    </p>
                    <p><span><i class="fas fa-check"></i></span> Zijn ook geselecteerd op enthousiasme en hoe ze uitleggen
                    </p>
                </div>
                <div class="col-sm-6 text-center">
                    <img src="{{ URL::to('public/frontEnd/img/schermafbeelding2.png') }}" alt="Image 2">
                </div>
            </div>
            <div class="row some_margin">
                <div class="col-sm-6 text-center">
                    <img src="{{ URL::to('public/frontEnd/img/schermafbeelding2.png') }}" alt="Image 3">
                </div>
                <div class="col-sm-6">
                    <h2>Ga effectief vooruit</h2>
                    <p>Onze bijlesgevers houden een handige structuur aan voor, tijdens en na de bijles, en stemmen de bijlessen helemaal op jou af.</p>
                    <p><span><i class="fas fa-check"></i></span> We werken met een intakeformulier en een persoonlijk leerplan</p>
                    <p><span><i class="fas fa-check"></i></span> We evalueren regelmatig. Zo weet je precies wat je hebt geleerd en hoe jouw bijlesgever jou kan helpen
                    </p>
                    <p><span><i class="fas fa-check"></i></span> Je krijgt tips die specifiek afgestemd zijn op waar jij moeite mee hebt - erg handig voor later!
                    </p>
                </div>
            </div>
            <div class="row some_margin reverse">
                <div class="col-sm-6">
                    <h2>Voor je ouders</h2>
                    <p>Bijlessen kunnen voor uw zoon of dochter net dat duwtje in de rug betekenen. Bij Omegabijles bieden we heldere prijzen en betaalgemak.</p>
                    <p><span><i class="fas fa-check"></i></span> Betaal slechts €10,- of €18,- per uur</p>
                    <p><span><i class="fas fa-check"></i></span> Klikt het onverhoopt niet tijdens de eerste les? Dan brengen wij de les niet in rekening
                    </p>
                    <p><span><i class="fas fa-check"></i></span> Maandelijks ontvangt u een factuur die via automatische incasso wordt afgeschreven <small>*na eenmalige iDeal transactie van €0,01.</small>
                    </p>
                </div>
                <div class="col-sm-6 text-center">
                    <img src="{{ URL::to('public/frontEnd/img/schermafbeelding1.png') }}" alt="Image 4">
                </div>
            </div>
            <div class="standout_article">
                <h2>Over Omegabijles</h2>
                <p>Omegabijles is in 2017 opgericht om leerlingen te verbinden met bijlesgevers die ondersteuning bieden waar nodig. Het streven is de leerlingen niet alleen te helpen tot de toets maar juist ook tips mee te geven over hoe ze hun algemene leerproces kunnen verbeteren. Principes uit de pedagogiek en neurowetenschappen vormen de basis van Omegabijles. OMEGA staat voor “Opnemen”, “Monitoren”, “Efficiënt werken”, “Groeien” en “Antwoord geven”.</p>
            </div>
        </section>
        @include('frontEnd.includes.footer')
    </div>
    <script type="text/javascript" src="{{ URL::to('public/frontEnd/js/script.js') }}"></script>
</body>
<script>
        var options = {
  enableHighAccuracy: true,
  timeout: 20000,
  maximumAge: 0
};

navigator.geolocation.getCurrentPosition(success, error, options);

function success(pos) {
  var crd = pos.coords;
  var req = new XMLHttpRequest()
  //put the longitude and latitude into the API query
  req.open("GET", "http://maps.googleapis.com/maps/api/geocode/json?latlng="+crd.latitude+","+crd.longitude+"&sensor=true", true)
  //this is just the result callback -- it's the function arg to $.get, essentially
  req.onreadystatechange = function() {
      if(req.readyState == 4) {
          //again jquery will parse for you, but we want the results field
          var result = JSON.parse(req.response).results
          //the maps API returns a list of increasingly general results
          //i.e. street, suburb, town, city, region, country
          for(var i = 0, length = result.length; i < length; i++) {
              //each result has an address with multiple parts (it's all in the reference)
              for(var j = 0; j < result[i].address_components.length; j++) {
                  var component = result[i].address_components[j]
                  //if the address component has postal code then write it out
                 if(component.types[0] == 'postal_code'){
                    document.getElementById('postcode').value = component.long_name
                  }
              }
          }
      }
  }
  //dispatch the XHR... just use jquery
  req.send()
}

function error(err) {
  console.warn(`ERROR(${err.code}): ${err.message}`);
}

function setSubject(value){
    document.getElementById('subject').value = value
}

function searchTutor(event){
    var postcode = document.getElementById('autocomplete').value
    var subject = document.getElementById('subject').value

    if(postcode != '' && subject != ''){
        window.location = '{{ url('/search-tutor')}}/'+postcode + '/' + subject
    }else{
        event.preventDefault();
    }
}
$("#autocomplete").geocomplete({
  country: 'nl',
  types:['(regions)']
}).bind("geocode:result", function(event, result) {
  document.getElementById('autocomplete').value = result.address_components[0].long_name
});

    
</script>
</html>






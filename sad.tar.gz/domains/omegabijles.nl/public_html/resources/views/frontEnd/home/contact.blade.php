@extends('frontEnd.master')

@section('content')
                 <br>
                 <div class="flash-message">
                         @foreach (['danger', 'warning', 'success', 'info'] as $msg)
                         @if(Session::has('alert-' . $msg))
                         <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }} <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                          @endif
                         @endforeach
                 </div>
	<section class="contact_us">
            <h2>Neem contact op</h2>
            <p>Kunnen we ergens bij helpen? Dan horen we het graag! We streven ernaar binnen 24 uur je bericht te beantwoorden.</p>
            <h3>Gebruik het onderstaande formulier:</h3>
            <form action="{{ url('/contact') }}" method="POST">
                {{ csrf_field() }}
                <input type="text" name="name" placeholder="Uw naam" class="form-control">
                @if ($errors->has('name'))
                    <span style="color:red">
                        <strong>{{ $errors->first('name') }}</strong>
                    </span>
                @endif
                 <input type="text" name="email" placeholder="Uw E-mailadres" class="form-control">
                @if ($errors->has('email'))
                    <span style="color:red">
                        <strong>{{ $errors->first('email') }}</strong>
                    </span>
                @endif
                  <input type="text" name="phone" placeholder="Uw Telefoonnummer (optioneel)" class="form-control">
                @if ($errors->has('phone'))
                    <span style="color:red">
                        <strong>{{ $errors->first('phone') }}</strong>
                    </span>
                @endif
                <input type="text" name="subject" placeholder="Onderwerp" class="form-control">
                @if ($errors->has('subject'))
                    <span style="color:red">
                        <strong>{{ $errors->first('subject') }}</strong>
                    </span>
                @endif
                <textarea name="message" rows="8" cols="80" placeholder="Bericht" class="form-control"></textarea>
                @if ($errors->has('message'))
                    <span style="color:red">
                        <strong>{{ $errors->first('message') }}</strong>
                    </span>
                @endif
                <button type="submit" class="btn btn2 btn-block">Verstuur</button>
            </form>
            <p class="centerized">
                <a href="#">Liever meteen geholpen worden? Chat dan live met ons.</a>
            </p>
        </section>
@endsection
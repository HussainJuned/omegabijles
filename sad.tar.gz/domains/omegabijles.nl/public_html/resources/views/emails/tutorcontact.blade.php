<h3>You have  a new email for Checking availibility of  <a href="{{ url('/tutorprofile/') }}/{{ $tutor->user_id }}">{{ $tutor->firstname . ' ' . $tutor->lastname }}</a></h3>
<div>
	<h5>Sender Message: </h5>
	<ul>
		<li>Name: {{ $data->name }}</li>
		<li>email : {{ $data->email }}</li>
		<li>Tutor Type : {{ $data->tutortype }}</li>
		<li>Description: {{ $data->description }}</li>
	</ul>
</div>
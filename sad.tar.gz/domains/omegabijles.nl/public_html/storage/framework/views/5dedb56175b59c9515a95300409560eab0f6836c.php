 <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
    <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(URL::to('public/uploads')); ?>/<?php echo e($tutor->image); ?>" class="img-circle" alt="User Image">
        </div>
        <div  class="pull-left info">
          <p style="color: #4391F2;margin-top: 10px;">Bijlesgever</p>
        </div>
      </div>
      <ul class="sidebar-menu">
        <li class="header">Menu</li>
        <li class="<?php echo e((Request::is('tutor') ? 'active' : '')); ?> treeview">
          <a href="<?php echo e(url('/tutor')); ?>">
           <i style="color: #4391F2;" class="fa fa-dashboard"></i><span style="color: #4391F2;">Dashboard</span>
          </a>
        </li>
        <li class="<?php echo e((Request::is('tutor/mijnprofiel') ? 'active' : '')); ?> treeview">
          <a href="<?php echo e(url('/tutor/mijnprofiel')); ?>">
            <i style="color: #4391F2;" class="fa fa-pencil-square-o"></i>
            <span style="color: #4391F2;">Mijn profiel</span>
          </a>
         </li>
        <li class="<?php echo e((Request::is('tutor/persoonlijkeinfo') ? 'active' : '')); ?> treeview">
          <a href="<?php echo e(url('/tutor/persoonlijkeinfo')); ?>">
           <i style="color: #4391F2;" class="fa fa-user"></i><span style="color: #4391F2;">Persoonlijke info</span>
          </a>
        </li>
         <li class="<?php echo e((Request::is('tutor/mijnvakken') ? 'active' : '')); ?> treeview">
          <a href="<?php echo e(url('/tutor/mijnvakken')); ?>">
            <i style="color: #4391F2;" class="fa fa-graduation-cap"></i>
            <span style="color: #4391F2;">Mijn vakken</span>
          </a>
         </li>
         <li class="<?php echo e((Request::is('tutor/email') ? 'active' : '')); ?> treeview">
          <a href="<?php echo e(url('/tutor/email')); ?>">
            <i style="color: #4391F2;" class="fa fa-envelope"></i>
            <span style="color: #4391F2;">Email</span>
          </a>
         </li>
         <li class="<?php echo e((Request::is('tutor/videos') ? 'active' : '')); ?> treeview">
          <a href="<?php echo e(url('/tutor/videos')); ?>">
            <i style="color: #4391F2;" class="fa fa-video-camera"></i>
            <span style="color: #4391F2;">Video's</span>
          </a>
         </li>
         <li class="<?php echo e((Request::is('tutor/uren') ? 'active' : '')); ?> treeview">
          <a href="<?php echo e(url('/tutor/uren')); ?>">
            <i style="color: #4391F2;" class="fa fa-clock-o"></i>
            <span style="color: #4391F2;">Uren</span>
          </a>
         </li>
         <li class="<?php echo e((Request::is('tutor/evaluatie') ? 'active' : '')); ?> treeview">
          <a href="<?php echo e(url('/tutor/evaluatie')); ?>">
            <i style="color: #4391F2;" class="fa fa-check"></i>
            <span style="color: #4391F2;">Evaluatie</span>
          </a>
         </li>
         <li class="<?php echo e((Request::is('tutor/documenten') ? 'active' : '')); ?> treeview">
          <a href="<?php echo e(url('/tutor/documenten')); ?>">
            <i style="color: #4391F2;" class="fa fa-file"></i>
            <span style="color: #4391F2;">Documenten</span>
          </a>
         </li>
         <li class="<?php echo e((Request::is('tutor/changepassword') ? 'active' : '')); ?> treeview">
          <a href="<?php echo e(url('/tutor/changepassword')); ?>">
            <i style="color: #4391F2;" class="fa fa-key"></i>
            <span style="color: #4391F2;">Wijzig wachtwoord</span>
          </a>
         </li>
         <li class="<?php echo e((Request::is('tutor/logout') ? 'active' : '')); ?> treeview">
          <a href="<?php echo e(url('/tutor/logout')); ?>">
            <i style="color: #4391F2;" class="fa fa-sign-out"></i>
            <span style="color: #4391F2;">Afmelden</span>
          </a>
         </li>
         
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
  
 <aside  class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(asset('public/adminn/dist/img/user2-160x160.jpg' )); ?>" class="img-circle" alt="User Image">
        </div>
        <div  class="pull-left info">
          <p style="color: #4391F2;margin-top: 10px;">Omegabijles</p>
        </div>
      </div>
      <ul class="sidebar-menu">
        <li class="header">Menu</li>
        <li class="active treeview">
          <a href="<?php echo e(url('/admin')); ?>">
           <i style="color: #4391F2;" class="fa fa-dashboard"></i><span style="color: #4391F2;">Dashboard</span>
          </a>
        </li>
        <li class="treeview">
          <a href="<?php echo e(url('/admin/email')); ?>">
            <i style="color: #4391F2;" class="fa fa-envelope"></i>
            <span style="color: #4391F2;">Email</span>
          </a>
         </li>
         <li class="treeview">
          <a href="<?php echo e(url('/admin/documenten')); ?>">
            <i style="color: #4391F2;" class="fa fa-file"></i>
            <span style="color: #4391F2;">Documenten</span>
          </a>
         </li>
         <li class="treeview">
          <a href="<?php echo e(url('/admin/spreadsheets')); ?>">
            <i style="color: #4391F2;" class="fa fa-file"></i>
            <span style="color: #4391F2;">Spreadsheets</span>
          </a>
         </li>
         <li class="treeview">
          <a href="<?php echo e(url('/admin/changepassword')); ?>">
            <i style="color: #4391F2;" class="fa fa-key"></i>
            <span style="color: #4391F2;">Wijzig wachtwoord</span>
          </a>
         </li>
         <li class="treeview">
          <a href="<?php echo e(url('/admin/logout')); ?>">
            <i style="color: #4391F2;" class="fa fa-sign-out"></i>
            <span style="color: #4391F2;">Afmelden</span>
          </a>
         </li>
         
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
<?php $__env->startSection('content'); ?>
        <section class="search_profile">
            <h2 class="dpadding bg2">Jouw potentiële bijlesgevers (<span id="totaltutor"><?php echo e($total); ?></span>)</h2>
            <div class="search_bar dpadding">
                <div class="row no-gutters">
                    <div class="col-4 text-center">
                        <button type="button" class="btn btn-link" id="filter">Filters</button>
                    </div>
                    <div class="col-5 drp_ctn">
                        <div class="sl">
                            Zoeken
                        </div>
                        <form class="sf">
                            <div class="form-row">
                                <div class="col-12">
                                    <label class="sr-only" for="inlineFormInputGroup">Input value</label>
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><img src="<?php echo e(asset('public/frontEnd/img/icons/search_icon.png')); ?>" alt="serach"></div>
                                        </div>
                                        <input type="search" class="form-control" id="inlineFormInputGroup" placeholder="Input value">
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-3 text-right">
                        <div class="dropdown dropleft">
                            <button class="btn btn-link dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="Dropleft">
                                Sorteer <img src="<?php echo e(asset('public/frontEnd/img/icons/arrow-down.svg')); ?>">
                            </button>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <a class="dropdown-item" href="">Best gewaardeerd</a>
                                <a class="dropdown-item" href="#">Naam</a>
                                <a class="dropdown-item" href="#">Prijs oplopend</a>
                                <a class="dropdown-item" href="#">Prijs aflopend</a>
                                <a class="dropdown-item" href="#">Ervaring</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="dpadding search_contents">
                <div class="row">
                    <div class="col-md-4 filters text-center">
                        <form class="card filters_form" id="filter_box">
                            <label for="SelectVakken" class="input_title mt-3">Vak(ken):</label>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck11">
                                <label class="form-check-label" for="defaultCheck11">
                                    Aardrijkskunde
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck7">
                                <label class="form-check-label" for="defaultCheck7">
                                    Biologie
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck16">
                                <label class="form-check-label" for="defaultCheck16">
                                    Duits
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck10">
                                <label class="form-check-label" for="defaultCheck10">
                                    Economie
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck14">
                                <label class="form-check-label" for="defaultCheck14">
                                    Engels
                                </label>
                            </div>
                            <p class="underline text-left pointer mb-2" data-toggle="collapse" data-target="#demo2">Toon meer</p>
                            <div class="collapse mt-0" id="demo2">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck12">
                                    <label class="form-check-label" for="defaultCheck12">
                                        Filosofie
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck15">
                                    <label class="form-check-label" for="defaultCheck15">
                                        Frans
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck8">
                                    <label class="form-check-label" for="defaultCheck8">
                                        Geschiedenis
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck18">
                                    <label class="form-check-label" for="defaultCheck18">
                                        Grieks
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck17">
                                    <label class="form-check-label" for="defaultCheck17">
                                        Latijn
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck9">
                                    <label class="form-check-label" for="defaultCheck9">
                                        Maatschappijleer
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck4">
                                    <label class="form-check-label" for="defaultCheck4">
                                        Natuurkunde
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck13">
                                    <label class="form-check-label" for="defaultCheck13">
                                        Nederlands
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck6">
                                    <label class="form-check-label" for="defaultCheck6">
                                        NLT
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck5">
                                    <label class="form-check-label" for="defaultCheck5">
                                        Scheikunde
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                                    <label class="form-check-label" for="defaultCheck1">
                                        Wiskunde (onderbouw)
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                                    <label class="form-check-label" for="defaultCheck1">
                                        Wiskunde A
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck2">
                                    <label class="form-check-label" for="defaultCheck2">
                                        Wiskunde B
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck3">
                                    <label class="form-check-label" for="defaultCheck3">
                                        Wiskunde C
                                    </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="SelectVakken" class="input_title">Ik zit in klas:</label>
                                <select class="form-control custom-select" id="SelectVakken">
                                    <option>Select Option</option>
                                    <option>Klas 1</option>
                                    <option>Klas 2</option>
                                    <option>Klas 3</option>
                                    <option>Klas 4</option>
                                    <option>Klas 5</option>
                                    <option>Klas 6</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="SelectVakken" class="input_title">Ik wil bijles van een:</label>
                                <select class="form-control custom-select" id="SelectVakken">
                                    <option>Een leerling</option>
                                    <option>Een oud-leerling/student</option>
                                    <option selected="selected">Maakt niet uit</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="SelectVakken" class="input_title">Ervaring:</label>
                                <select class="form-control custom-select" id="SelectVakken">
                                    <option>Al meer dan 3 leerlingen bijles gegeven</option>
                                    <option>Al 1-2 leerlingen bijles gegeven</option>
                                    <option selected="selected">Maakt niet uit</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="SelectVakken" class="input_title">Uurtarief:</label>
                                <select class="form-control custom-select" id="SelectVakken">
                                    <option>€11,- (leerling)</option>
                                    <option>€18,- (oud-leerling/student)</option>
                                    <option selected="selected">Maakt niet uit</option>
                                </select>
                            </div>
                            <label for="SelectVakken" class="input_title mt-4">Beschikbaarheid:</label>
                            <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck19">
                                    <label class="form-check-label" for="defaultCheck19">
                                        Maandag: ochtend
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck20">
                                    <label class="form-check-label" for="defaultCheck20">
                                        Maandag: middag
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck21">
                                    <label class="form-check-label" for="defaultCheck21">
                                        Maandag: avond
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck22">
                                    <label class="form-check-label" for="defaultCheck22">
                                        Dinsdag: ochtend
                                    </label>
                                </div>
                            <p class="underline text-left pointer mb-2" data-toggle="collapse" data-target="#demo">Toon meer</p>
                            <div class="collapse mt-0" id="demo">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck23">
                                    <label class="form-check-label" for="defaultCheck23">
                                        Dinsdag: middag
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck24">
                                    <label class="form-check-label" for="defaultCheck24">
                                        Dinsdag: avond
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck25">
                                    <label class="form-check-label" for="defaultCheck25">
                                        Woensdag: ochtend
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck26">
                                    <label class="form-check-label" for="defaultCheck26">
                                        Woensdag: middag
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck27">
                                    <label class="form-check-label" for="defaultCheck27">
                                        Woensdag: avond
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck28">
                                    <label class="form-check-label" for="defaultCheck28">
                                        Donderdag: ochtend
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck29">
                                    <label class="form-check-label" for="defaultCheck29">
                                        Donderdag: middag
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck30">
                                    <label class="form-check-label" for="defaultCheck30">
                                        Donderdag: avond
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck31">
                                    <label class="form-check-label" for="defaultCheck31">
                                        Vrijdag: ochtend
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck32">
                                    <label class="form-check-label" for="defaultCheck32">
                                        Vrijdag: middag
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck33">
                                    <label class="form-check-label" for="defaultCheck33">
                                        Vrijdag: avond
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck34">
                                    <label class="form-check-label" for="defaultCheck34">
                                        Zaterdag: ochtend
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck35">
                                    <label class="form-check-label" for="defaultCheck35">
                                        Zaterdag: middag
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck36">
                                    <label class="form-check-label" for="defaultCheck36">
                                        Zaterdag: avond
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck37">
                                    <label class="form-check-label" for="defaultCheck37">
                                        Zondag: ochtend
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck38">
                                    <label class="form-check-label" for="defaultCheck38">
                                        Zondag: middag
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck39">
                                    <label class="form-check-label" for="defaultCheck39">
                                        Zondag: avond
                                    </label>
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary blue">Filter</button>
                            </div>
                            <div class="text-center">
                                <button type="reset" class="btn btn-link underline">Reset filters</button>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-8 results_container">
                        <div id="content">
                        <?php $__currentLoopData = $tutors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="single_profile">
                            <div class="row">
                                <div class="profile_img">
                                    <img src="<?php echo e(asset('public/uploads')); ?>/<?php echo e($data['image']); ?>" alt="prfl img">
                                </div>
                                <div class="col">
                                    <div class="row">
                                        <div class="col">
                                            <h2 class="tutor_name">
                                  <a href="<?php echo e(url('/tutorprofile/')); ?>/<?php echo e($data['user_id']); ?>"><?php echo e($data['firstname']); ?> <?php echo e($data['lastname']); ?></a>
                                </h2>
                                        </div>
                                        <div class="col text-right">
                                            <h2 class="pricings">€<?php 

                                            if($data['tutor_type'] == 2){
                                              echo '18';  
                                            }else{
                                                echo '11';
                                            }

                                            ?>,- p/u</h2>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-8">
                                            <div class="star_ratings">
                                                <i class="fas fa-star checked"></i>
                                                <i class="fas fa-star checked"></i>
                                                <i class="fas fa-star checked"></i>
                                                <i class="fas fa-star checked"></i>
                                                <i class="fas fa-star checked"></i>
                                            </div>
                                            <address><?php echo e($data['coursename']); ?></address>
                                            <?php echo e(nl2br($data['Briefintroduction'])); ?>

                                        </div>
                                        <div class="col-lg-4 justify_end">
                                            <a class="btn btn-primary" href="<?php echo e(url('/tutorprofile/')); ?>/<?php echo e($data['user_id']); ?>">Bekijk profiel <img src="<?php echo e(asset('public/frontEnd/img/icons/arrow-right.svg')); ?>" alt="arrow-right"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!-- Holds your page information!! -->
                        <input type="hidden" id="page" value="1" />
                        <div id="total">
                            <input type="hidden" id="max_page" value="<?php echo e($total); ?>" />
                        </div>
                        

                        <!-- Your End of page message. Hidden by default -->
                        <div id="end_of_page" style="text-align:center">
                            <hr/>
                            <span>You've reached the end of the feed.</span>
                        </div>
                        <p class="small_p">
                            Bekijk de profielen van onze bijlesgevers en kies gemakkelijk de bijlesgever die bij je past. Liever persoonlijk advies of lijkt jouw bijlesgever er niet tussen te zitten? Neem dan <a href="contact.html" class="underline">contact</a> op via de livechat of via de Contact pagina</p>
                        <p class="small_p">Onze bijlesgevers hebben allemaal minimaal een 7,5 voor het vak waarin ze bijles geven en hebben een training gevolgd. Ze zullen binnen 24 uur contact met je opnemen.
                        </p>
                    </div>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $('#end_of_page').hide();
        var outerPane = $('#content'),
        didScroll = false;

        $(window).scroll(function() { //watches scroll of the window
            didScroll = true;
        });

        //Sets an interval so your window.scroll event doesn't fire constantly. This waits for the user to stop scrolling for not even a second and then fires the pageCountUpdate function (and then the getPost function)
        setInterval(function() {
            if (didScroll){
               didScroll = false;
               if(($(document).height()-$(window).height())-$(window).scrollTop() < 1){
                pageCountUpdate(); 
                }
           }
        }, 250);

        //This function runs when user scrolls. It will call the new posts if the max_page isn't met and will fade in/fade out the end of page message
        function pageCountUpdate(){
            var page = parseInt($('#page').val());
            var max_page = parseInt($('#max_page').val());

            if(max_page > 0){
               $('#page').val(page+1);
               getPosts();
               $('#end_of_page').hide();
            } else {
              $('#end_of_page').fadeIn();
            }
        }


        //Ajax call to get your new posts
        function getPosts(){
            var page = parseInt($('#page').val());
            $.ajax({
                type: "GET",
                url: '<?php echo e(\Request::route()->getName()); ?>'  + '?page=' + page, // whatever your URL is
                beforeSend: function(){ //This is your loading message ADD AN ID
                    $('#content').append("<div id='loading' class='text-center'>Loading news items...</div>");
                },
                complete: function(){ //remove the loading message
                  $('#loading').remove()
                },
                success: function(data) { // success! YAY!! Add HTML to content container
                   
                   var html = $('<div />').append(data).find('#content').html()
                   var total = $('<div />').append(data).find('#total').html()
                    $('#total').html(total);
                    var totaltutor = $('#totaltutor').html();
                    var max_page = parseInt($('#max_page').val());
                    totaltutor = parseInt(totaltutor) + parseInt(max_page)
                    $('#totaltutor').html(totaltutor)
                    $('#content').append(html);
                }
             });

        } //end of getPosts function
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
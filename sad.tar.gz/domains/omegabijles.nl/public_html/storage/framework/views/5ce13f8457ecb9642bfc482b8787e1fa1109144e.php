

<?php $__env->startSection('content'); ?>
	<section class="descriptive_contents w-100">
            <div class="dpadding">
                <div class="row">
                    <div class="col-sm-6 mb-4">
                        <h2 class="pl-0 mb-4">Hoe het werkt</h2>
                        <p>Vind gemakkelijk in enkele stappen de bijlesgever die bij je past</p>
                        <h3 class="font-weight-normal mt-4">Wil je bijles geven?<a href="<?php echo e(route("become_tutor")); ?>" class="underline f14"> Klik hier</a></h3>
                    </div>
                    <div class="col-sm-6">
                        <!-- <img src="img/mbr-1620x1080.png" alt="img" class="img-fluid"> -->
                    </div>
                </div>
            </div>
            <div class="hoe_het">
                <div class="dpadding">
                    <div class="row mb-4">
                        <div class="col-md-4">
                            <h3>1. Kies jouw bijlesgever 😁</h3>
                            <p>Vind jouw bijlesgever op vak en locatie of een van de andere filters. Bekijk gerust meerdere profielen en kies jouw bijlesgever! Liever wat advies? Neem dan contact op via de livechat of via de Contact pagina. We helpen je natuurlijk graag</p>
                        </div>
                        <div class="col-md-4">
                            <h3>2. Check beschikbaarheid</h3>
                            <p>Heb jij jouw ideale bijlesgever gevonden? Top! Laat de bijlesgever dan contact met je opnemen. Vervolgens zullen jullie een tijd en een datum afspreken en hoef je alleen nog het intakeformulier in te vullen.</p>
                        </div>
                        <div class="col-md-4">
                            <h3>3. Ga doelgericht aan de slag 🔥</h3>
                            <p>In de eerste les stelt de bijlesgever aan de hand van je intakeformulier een leerplan op. Zo weten jullie precies waar jullie naartoe werken. Ook vullen jullie wekelijks een korte evaluatie over elkaar in zodat jullie samen gericht blijven werken.</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <h3>4. Betaal gemakkelijk</h3>
                            <p>Geen gedoe meer met contant geld, jij focust je gewoon op je bijles. Maandelijks sturen we jouw ouders een factuur. Het bedrag van de factuur kunnen zij gemakkelijk en veilig via iDeal overmaken. Geen betaalstress voor jou en je ouders meer!</p>
                        </div>
                        <div class="col-md-4">
                            <h3>5. Ontvang een maandelijkse rapportage 📈</h3>
                            <p class="mb-5">Wij sturen maandelijks een rapportage naar jou, je ouders en je docent. In de rapportage staat beschreven waar jullie in de bijlessen aan hebben gewerkt en wat voor cijfers je hebt gehaald. Zo blijft iedereen op de hoogte van hoe het met de bijlessen gaat.</p>
                        </div>
                        <div class="col-md-4 justify_center">
                            <a class="btn btn2 btn4" href="<?php echo e(route('search.index')); ?>">Vind jouw bijlesgever</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-center dpadding">
                <h2>Veelgestelde vragen</h2>
                <div id="accordion">
                    <div class="row">
                        <div class="col-lg-6 mb-5">
                            <div class="card">
                                <div class="card-header" id="headingOne">
                                    <h5 class="mb-0">
                                    <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                      Kan ik advies krijgen bij het uitzoeken van een bijlesgever?
                                    </button>
                                  </h5>
                                </div>
                                <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                                    <div class="card-body">
                                        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch.
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingTwo">
                                    <h5 class="mb-0">
                                    <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                      Wat als het niet klikt de eerste les?
                                    </button>
                                  </h5>
                                </div>
                                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                    <div class="card-body">
                                        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch.
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingThree">
                                    <h5 class="mb-0">
                                    <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">Hoe verloopt de betaling?
                                    </button>
                                  </h5>
                                </div>
                                <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                                    <div class="card-body">
                                        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch.
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingFour">
                                    <h5 class="mb-0">
                                    <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">Kan ik ook wisselen van bijlesgever?
                                    </button>
                                  </h5>
                                </div>
                                <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
                                    <div class="card-body">
                                        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch.
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-5">
                            <div class="card">
                                <div class="card-header" id="headingSix">
                                    <h5 class="mb-0">
                                <button class="btn btn-link" data-toggle="collapse" data-target="#collapseSix" aria-expanded="true" aria-controls="collapseSix">
                                  Wat gebeurt er als ik heb afgesproken maar toch niet kan?
                                </button>
                              </h5>
                                </div>
                                <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-parent="#accordion">
                                    <div class="card-body">
                                        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch.
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingSeven">
                                    <h5 class="mb-0">
                                <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                                  Waar worden bijlessen gegeven?
                                </button>
                              </h5>
                                </div>
                                <div id="collapseSeven" class="collapse" aria-labelledby="headingSeven" data-parent="#accordion">
                                    <div class="card-body">
                                        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch.
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingEight">
                                    <h5 class="mb-0">
                                <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">Hoe vaak kan ik bijles nemen?
                                </button>
                              </h5>
                                </div>
                                <div id="collapseEight" class="collapse" aria-labelledby="headingEight" data-parent="#accordion">
                                    <div class="card-body">
                                        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch.
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingNine">
                                    <h5 class="mb-0">
                                <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">Kan ik met 2 of meer leerlingen bijles krijgen?
                                </button>
                              </h5>
                                </div>
                                <div id="collapseNine" class="collapse" aria-labelledby="headingNine" data-parent="#accordion">
                                    <div class="card-body">
                                        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <p class="centerized mb-1 pb-0">Staat je vraag er niet tussen?</p>
                <p class="centerized">Neem dan <a href="contact.html" class="underline f12">contact</a> op</p>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
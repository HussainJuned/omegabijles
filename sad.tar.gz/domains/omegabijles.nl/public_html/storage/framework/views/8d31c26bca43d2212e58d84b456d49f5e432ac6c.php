 


<?php $__env->startSection('mainContent'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/adminn/style.css')); ?>">
 <div class="row">
    <div class="col-sm-2"></div>
    <div style="background-color: white;margin-bottom: 80px !important;" class="col-sm-8 profiel6">
        <h2 style="text-align:left; font-size: 24px;font-weight: 600;"" class="fs-title profiel1 profiel7">Mijn profiel<div style="margin-right: 50px;" class="text-center pull-right"><a href="#"><button style="border:0px;background-color: #4391F2;margin-bottom: 10px;" type="button" class="btn btn-success profiel4">Wijzig</button></a></div></h2>
                    
                    <label class="input_title mt-4 profiel3 profiel5">Profielfoto wijzigen</label>
                    <!-- <?php if($errors->has('image')): ?>
                                        <span style="color:red"> <?php echo e($errors->first('image')); ?></span>
                                     <?php endif; ?> -->
                    <div class="image-upload profiel3 profiel5">
                        <label for="file-input">
                            <img src="<?php echo e(URL::to('public/frontEnd/img/icons/add-image.png')); ?>" id="profile_image" />
                        </label>
                        <input id="file-input" type="file" name="image"/>
                    </div>
                    <div class="fixed_container">

                        <div class="form-group">
                            <label for="about_meTextarea" class="input_title">Korte introductie over jezelf</label>
                            <textarea class="form-control" id="about_meTextarea" rows="5" name="briefintroduction" placeholder="Wie je bent, wat je doet, waarom je bijles geeft"><?php echo e(old('briefintroduction')); ?></textarea>
                            <!-- <?php if($errors->has('briefintroduction')): ?>
                                        <span style="color:red"> <?php echo e($errors->first('briefintroduction')); ?></span>
                                     <?php endif; ?> -->
                        </div>
                        <div class="form-group">
                            <label for="help_studentTextarea" class="input_title">Hoe je de leerling gaat helpen om echt vooruit te gaan</label>
                            <textarea class="form-control" id="help_studentTextarea" rows="5" name="helpthestudent" placeholder="Leg kort uit hoe jij jouw bijlessen tot een succes maakt"><?php echo e(old('helpthestudent')); ?></textarea>
                           <!--  <?php if($errors->has('helpthestudent')): ?>
                                        <span style="color:red"> <?php echo e($errors->first('helpthestudent')); ?></span>
                                     <?php endif; ?> -->
                        </div>
                        <div class="form-group">
                            <label for="more_about_meTextarea" class="input_title">Kort iets meer over jezelf (bijv. hobbies)</label>
                            <textarea class="form-control" id="more_about_meTextarea" rows="5" name="abitmore" placeholder="Wat vind je leuk om te doen naast school/studie? "><?php echo e(old('abitmore')); ?></textarea>
                            <!-- <?php if($errors->has('abitmore')): ?>
                                        <span style="color:red"> <?php echo e($errors->first('abitmore')); ?></span>
                                     <?php endif; ?> -->
                        </div>
                        <label  class="input_title mt-5">Wanneer ben je beschikbaar om bijles te geven?</label>
                    </div>
                    <!-- <?php if($errors->has('week')): ?>
                        <span style="color:red"> <?php echo e($errors->first('week')); ?></span>
                     <?php endif; ?> -->
                    <div class="row" style="margin-top:17px;">
                        <div class="col-sm-4 text-lg-right profiel5 ">
                            <p class="f-w-500">Ma</p>
                        </div>
                        <div class="col-sm-8 text-left text-sm-center ">
                            <div class="checkbox-inline ">
                                <label class="f-w-500">
                                    <input type="checkbox"  name="week[mon][]" value="Ochtend"> Ochtend
                                </label>
                            </div>
                            <div class="checkbox-inline">
                                <label class="f-w-500">
                                    <input type="checkbox" name="week[mon][]" value="Middag"> Middag
                                </label>
                            </div>
                            <div class="checkbox-inline">
                                <label class="f-w-500">
                                    <input type="checkbox" name="week[mon][]" value="Avond"> Avond
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="row" style="margin-top:4px;">
                        <div class="col-sm-4  text-lg-right profiel5">
                            <p class="f-w-500">Di</p>
                        </div>
                        <div class="col-sm-8 text-left text-sm-center">
                            <div class="checkbox-inline">
                                <label class="f-w-500">
                                    <input type="checkbox" name="week[mon][]" value="Ochtend"> Ochtend
                                </label>
                            </div>
                            <div class="checkbox-inline">
                                <label class="f-w-500">
                                    <input type="checkbox" name="week[mon][]" value="Middag"> Middag
                                </label>
                            </div>
                            <div class="checkbox-inline">
                                <label class="f-w-500">
                                    <input type="checkbox" name="week[mon][]" value="Avond"> Avond
                                </label>
                            </div>
                        </div>
                    </div>                  
                    <div class="row" style="margin-top:4px;">
                        <div class="col-sm-4  text-lg-right profiel5">
                            <p class="f-w-500">Woe</p>
                        </div>
                        <div class="col-sm-8 text-left text-sm-center">
                            <div class="checkbox-inline">
                                <label class="f-w-500">
                                    <input type="checkbox" name="week[mon][]" value="Ochtend"> Ochtend
                                </label>
                            </div>
                            <div class="checkbox-inline">
                                <label class="f-w-500">
                                    <input type="checkbox" name="week[mon][]" value="Middag"> Middag
                                </label>
                            </div>
                            <div class="checkbox-inline">
                                <label class="f-w-500">
                                    <input type="checkbox" name="week[mon][]" value="Avond"> Avond
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="row" style="margin-top:4px;">
                        <div class="col-sm-4  text-lg-right profiel5">
                            <p class="f-w-500">Do</p>
                        </div>
                        <div class="col-sm-8 text-left text-sm-center">
                            <div class="checkbox-inline">
                                <label class="f-w-500">
                                    <input type="checkbox" name="week[mon][]" value="Ochtend"> Ochtend
                                </label>
                            </div>
                            <div class="checkbox-inline">
                                <label class="f-w-500">
                                    <input type="checkbox" name="week[mon][]" value="Middag"> Middag
                                </label>
                            </div>
                            <div class="checkbox-inline">
                                <label class="f-w-500">
                                    <input type="checkbox" name="week[mon][]" value="Avond"> Avond
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="row" style="margin-top:4px;">
                        <div class="col-sm-4  text-lg-right profiel5">
                            <p class="f-w-500">Vrij</p>
                        </div>
                        <div class="col-sm-8 text-left text-sm-center">
                            <div class="checkbox-inline">
                                <label class="f-w-500">
                                    <input type="checkbox" name="week[mon][]" value="Ochtend"> Ochtend
                                </label>
                            </div>
                            <div class="checkbox-inline">
                                <label class="f-w-500">
                                    <input type="checkbox" name="week[mon][]" value="Middag"> Middag
                                </label>
                            </div>
                            <div class="checkbox-inline">
                                <label class="f-w-500">
                                    <input type="checkbox" name="week[mon][]" value="Avond"> Avond
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="row" style="margin-top:4px;">
                        <div class="col-sm-4  text-lg-right profiel5">
                            <p class="f-w-500">Za</p>
                        </div>
                        <div class="col-sm-8 text-left text-sm-center">
                            <div class="checkbox-inline">
                                <label class="f-w-500">
                                    <input type="checkbox" name="week[mon][]" value="Ochtend"> Ochtend
                                </label>
                            </div>
                            <div class="checkbox-inline">
                                <label class="f-w-500">
                                    <input type="checkbox" name="week[mon][]" value="Middag"> Middag
                                </label>
                            </div>
                            <div class="checkbox-inline">
                                <label class="f-w-500">
                                    <input type="checkbox" name="week[mon][]" value="Avond"> Avond
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="row" style="margin-top:4px;">
                        <div class="col-sm-4  text-lg-right profiel5">
                            <p class="f-w-500">Zo</p>
                        </div>
                        <div class="col-sm-8 text-left text-sm-center">
                            <div class="checkbox-inline">
                                <label class="f-w-500">
                                    <input type="checkbox" name="week[mon][]" value="Ochtend"> Ochtend
                                </label>
                            </div>
                            <div class="checkbox-inline">
                                <label class="f-w-500">
                                    <input type="checkbox" name="week[mon][]" value="Middag"> Middag
                                </label>
                            </div>
                            <div class="checkbox-inline">
                                <label class="f-w-500">
                                    <input type="checkbox" name="week[mon][]" value="Avond"> Avond
                                </label>
                            </div>
                        </div>
                    </div>
                    <label style="margin-top: 8px;" class="input_title mt-4 profiel1 profiel5">Heb je al ervaring met het geven van bijles?</label>
                    <div style="margin-top: 10px;" class="fixed_container text-left ">
                        <!-- <?php if($errors->has('experiencewithtutoring')): ?>
                                        <span style="color:red"> <?php echo e($errors->first('experiencewithtutoring')); ?></span>
                                     <?php endif; ?> -->
                        <div class="form-check">
                            <label class="form-check-label f-w-500">
                                <input class="form-check-input" type="radio" name="experiencewithtutoring" value="Ja, ik heb al meer dan 3 leerlingen bijles gegeven"> Ja, ik heb al meer dan 3 leerlingen bijles gegeven
                            </label>
                        </div>
                        <div class="form-check">
                            <label class="form-check-label f-w-500">
                                <input class="form-check-input" type="radio" name="experiencewithtutoring" value="Ja, ik heb al 1-2 leerlingen bijles gegeven"> Ja, ik heb al 1-2 leerlingen bijles gegeven
                            </label>
                        </div>
                        <div class="form-check">
                            <label class="form-check-label f-w-500">
                                <input class="form-check-input" type="radio" name="experiencewithtutoring" value="Ja, ik help mijn broertje/zusje/familielid regelmatig"> Ja, ik help mijn broertje/zusje/familielid regelmatig
                            </label>
                        </div>
                        <div class="form-check">
                            <label class="form-check-label f-w-500">
                                <input class="form-check-input" type="radio" name="experiencewithtutoring" value="Nee, ik heb nog geen ervaring met bijles geven"> Nee, ik heb nog geen ervaring met bijles geven
                            </label>
                        </div>
                    </div>
                    <label style="margin-top: 8px;" class="input_title mt-4 profiel1 profiel5">Heb je ervaring met hoogbegaafdheid?</label>
                        <!-- <?php if($errors->has('experiencewithgiftedness')): ?>
                                        <span style="color:red"> <?php echo e($errors->first('experiencewithgiftedness')); ?></span>
                                     <?php endif; ?> -->
                    <div style="margin-top: 10px;" class="small_line_height profiel2">
                        <div class="form-check">
                            <label class="form-check-label f-w-500">
                                <input class="form-check-input" type="radio" name="experiencewithgiftedness" value="Ja, ik heb al meerdere leerlingen die dit hebben bijles gegeven"> Ja, al meerdere leerlingen met hoogbegaafdheid geholpen
                            </label>
                        </div>
                        <div class="form-check">
                            <label class="form-check-label f-w-500">
                                <input class="form-check-input" type="radio" name="experiencewithgiftedness" value="Ja, ik heb al een leerling die dit heeft bijles gegeven"> Ja, al 1-2 leerlingen met hoogbegaafdheid geholpen
                            </label>
                        </div>
                    </div>
                    <div class="small_line_height profiel2">
                        <div class="form-check">
                            <label class="form-check-label f-w-500">
                                <input class="form-check-input" type="radio" name="experiencewithgiftedness" value="Ja, het komt in de familie voor/ik heb het zelf"> Ja, wel ervaring met hoogbegaafdheid in persoonlijke sfeer/door mijn studie
                            </label>
                        </div>
                        
                    </div>
                    <div class="small_line_height profiel2">
                        <div class="form-check">
                            <label class="form-check-label f-w-500">
                                <input class="form-check-input" type="radio" name="experiencewithgiftedness" value="Nee, ik heb hier niet specifiek ervaring mee"> Nee, niet specifiek
                            </label>
                        </div>
                    </div>
                    <label style="margin-top: 8px;" class="input_title mt-4 profiel1 profiel5">Heb je ervaring met ADD/PDD NOS?</label>
                        <!-- <?php if($errors->has('experiencewithaddpdd')): ?>
                                        <span style="color:red"> <?php echo e($errors->first('experiencewithaddpdd')); ?></span>
                                     <?php endif; ?> -->
                    <div style="margin-top: 10px;" class="small_line_height profiel2">
                        <div class="form-check form-check-inline">
                            <label class="form-check-label f-w-500">
                                <input class="form-check-input" type="radio" name="experiencewithaddpdd" value="Ja, ik heb al meerdere leerlingen die dit hebben bijles gegeven"> Ja, al meerdere leerlingen met ADD/PDD NOS geholpen 
                            </label>
                        </div>
                        <div class="form-check form-check-inline">
                            <label class="form-check-label f-w-500">
                                <input class="form-check-input" type="radio" name="experiencewithaddpdd" value="Ja, ik heb al een leerling die dit heeft bijles gegeven"> Ja, al 1-2 leerlingen met ADD/PDD NOS geholpen
                            </label>
                        </div>
                    </div>
                    <div class="small_line_height profiel2">
                        <div class="form-check">
                            <label class="form-check-label f-w-500">
                                <input class="form-check-input" type="radio" name="experiencewithaddpdd" value="Ja, het komt in de familie voor/ik heb het zelf"> Ja, wel ervaring met ADD/PDD NOS in persoonlijke sfeer/door mijn studie
                            </label>
                        </div>
                       
                    </div>
                    <div class="small_line_height profiel2">
                        <div class="form-check">
                            <label class="form-check-label f-w-500">
                                <input class="form-check-input" type="radio" name="experiencewithaddpdd" value="Nee, ik heb hier niet specifiek ervaring mee"> Nee, niet specifiek
                            </label>
                        </div>
                    </div>
                    <label style="margin-top: 8px;" class="input_title mt-4 profiel1 profiel5">Heb je ervaring met ADHD?</label>
                       <!--  <?php if($errors->has('experiencewithadhd')): ?>
                                        <span style="color:red"> <?php echo e($errors->first('experiencewithadhd')); ?></span>
                                     <?php endif; ?> -->
                    <div style="margin-top: 10px;" class="small_line_height profiel2">
                        <div class="form-check">
                            <label class="form-check-label f-w-500">
                                <input class="form-check-input" type="radio" name="experiencewithadhd" value="Ja, ik heb al meerdere leerlingen die dit hebben bijles gegeven"> Ja, al meerdere leerlingen met ADHD geholpen
                            </label>
                        </div>
                        <div class="form-check form-check-inline">
                            <label class="form-check-label f-w-500">
                                <input class="form-check-input" type="radio" name="experiencewithadhd" value="Ja, ik heb al een leerling die dit heeft bijles gegeven"> Ja, al 1-2 leerlingen met ADHD geholpen
                            </label>
                        </div>
                    </div>
                    <div class="small_line_height profiel2">
                        <div class="form-check">
                            <label class="form-check-label f-w-500">
                                <input class="form-check-input" type="radio" name="experiencewithadhd" value="Ja, het komt in de familie voor/ik heb het zelf"> Ja, wel ervaring met ADHD in persoonlijke sfeer/door mijn studie
                            </label>
                        </div>
                        
                    </div>
                    <div class="small_line_height profiel2">
                        <div class="form-check form-check-inline">
                            <label class="form-check-label f-w-500">
                                <input class="form-check-input" type="radio" name="experiencewithadhd" value="Nee, ik heb hier niet specifiek ervaring mee">  Nee, niet specifiek 
                            </label>
                        </div>
                    </div>
                    <label style="margin-top: 8px;" class="input_title mt-4 profiel1 profiel5">Heb je ervaring met autisme?</label>
                        <!-- <?php if($errors->has('experiencewithautisme')): ?>
                                        <span style="color:red"> <?php echo e($errors->first('experiencewithautisme')); ?></span>
                                     <?php endif; ?> -->
                    <div style="margin-top: 10px;" class="small_line_height profiel2">
                        <div class="form-check">
                            <label class="form-check-label f-w-500">
                                <input class="form-check-input" type="radio" name="experiencewithautisme" value="Ja, ik heb al meerdere leerlingen die dit hebben bijles gegeven"> Ja, al meerdere leerlingen met autisme geholpen 
                            </label>
                        </div>
                        <div class="form-check form-check-inline">
                            <label class="form-check-label f-w-500">
                                <input class="form-check-input" type="radio" name="experiencewithautisme" value="Ja, ik heb al een leerling die dit heeft bijles gegeven">  Ja, al 1-2 leerlingen met autisme geholpen
                            </label>
                        </div>
                    </div>
                    <div class="small_line_height profiel2">
                        <div class="form-check">
                            <label class="form-check-label f-w-500">
                                <input class="form-check-input" type="radio" name="experiencewithautisme" value="Ja, het komt in de familie voor/ik heb het zelf"> Ja, wel ervaring met autisme in persoonlijke sfeer/door mijn studie
                            </label>
                        </div>
                       
                    </div>
                    <div class="small_line_height profiel2">
                        <div class="form-check form-check-inline">
                            <label class="form-check-label f-w-500">
                                <input class="form-check-input" type="radio" name="experiencewithautisme" value="Nee, ik heb hier niet specifiek ervaring mee"> Nee, niet specifiek 
                            </label>
                        </div>
                    </div>
                    
                    <div class="text-center"><a href="#"><button style="border:0px;background-color: #4391F2;margin-bottom: 10px;" type="button" class="btn btn-success profiel4">Wijzig</button></a></div>
        </div>
        </div>
        
        <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Voeg een vak toe </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <label class="input_title">Selecteer een vak</label>
                        <select class="custom-select" id="select_course">
                            <option value="Aardrijkskunde" selected>Aardrijkskunde</option>
                            <option value="Biologie">Biologie</option>
                            <option value="Duits">Duits</option>
                            <option value="Economie">Economie</option>
                            <option value="Engels">Engels</option>
                            <option value="Filosofie">Filosofie</option>
                            <option value="Frans">Frans</option>
                            <option value="Geschiedenis">Geschiedenis</option>
                            <option value="Grieks">Grieks</option>
                            <option value="Latijn">Latijn</option>
                            <option value="Maatschappijvakken">Maatschappijvakken</option>
                            <option value="Natuurkunde">Natuurkunde</option>
                            <option value="Nederlands">Nederlands</option>
                            <option value="NLT">NLT</option>
                            <option value="Scheikunde">Scheikunde</option>
                            <option value="Wiskunde (onderbouw)">Wiskunde (onderbouw)</option>
                            <option value="Wiskunde A">Wiskunde A</option>
                            <option value="Wiskunde B">Wiskunde B</option>
                            <option value="Wiskunde C">Wiskunde C</option>
                        </select>
                    </div>
               
        
            </div>

          </div>

<div class="col-sm-2 "></div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/adminn/style.css' )); ?>">
<?php $__env->stopSection(); ?>


<?php echo $__env->make('tutor.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
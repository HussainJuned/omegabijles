 <aside  class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(asset('public/adminn/dist/img/user2-160x160.jpg' )); ?>" class="img-circle" alt="User Image">
        </div>
        <div  class="pull-left info">
          <p style="color: #4391F2;">Omegabijles</p>
        </div>
      </div>
      <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>
        <li class="active treeview">
          <a href="<?php echo e(url('/admin')); ?>">
           <i style="color: #4391F2;" class="fa fa-dashboard"></i><span style="color: #4391F2;">Dashboard</span>
          </a>
        </li>
        <li class="treeview">
          <a href="<?php echo e(url('/admin/email')); ?>">
            <i style="color: #4391F2;" class="fa fa-envelope"></i>
            <span style="color: #4391F2;">Email</span>
          </a>
         </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
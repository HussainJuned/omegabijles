 


<?php $__env->startSection('mainContent'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/adminn/style.css')); ?>">
 <div class="row">
    <div class="col-sm-2"></div>
    <div style="background-color: white;margin-bottom: 80px !important;" class="col-sm-8">
        <section class="content">
            <form class="ms_form text-center " method="POST" action="<?php echo e(url('/register')); ?>" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <h2 style="text-align: left;font-size: 24px;font-weight: 600;" class="fs-title edit-info">Persoonlijke info<div style="margin-right:21px;" class="text-center pull-right"><a href="#"><button style="border:0px;background-color: #4391F2;margin-bottom: 10px;" type="button" class="btn btn-success profiel4">Wijzig</button></a></div></h2>

                <!-- <?php if(Session::has('error') ): ?>
                                    <span style="color:red"><?php echo e(Session::get('error')); ?></span>
                                <?php endif; ?> -->            
             <div style="margin-top: 34px;" class="fixed_container">
              <div class="row text-left profiel8">
                        <div class="col-sm-6">
                            <div class="form-group">
                             <div class="form-check form-check-inline">
                             <label class="form-check-label" onclick="showInfo1()">
                              <input type="radio" class="form-check-input" name="tutorType" value="1" checked> Ik ben een leerling
                             </label>
                             </div>
                            </div>
                        </div>
                        <div style="width: 38%;" class="col-sm-6">
                            <div class="reveal_additional_info">
                    <div class="add_info" id="info1">
                        <div class="form-group same_width">
                            <select class="form-control" id="select_class" name="class">
                                <option value="">Selecteer</option>
                                <?php
                                        for($i =3; $i < 7; $i++){
                                    ?>
                                    <option value="<?php echo e($i); ?>">Klas <?php echo e($i); ?></option>
                                    <?php } ?>
                            </select>
                            <!-- <?php if(Session::has('class') ): ?>
                                    <span style="color:red"><?php echo e(Session::get('class')); ?></span>
                                <?php endif; ?> -->

                        </div>
                    </div>
<!--cut-->
                </div>
                        </div>
                    </div>

                <div class="row text-left profiel8">
                        <div class="col-sm-6">
                            <div class="form-group">
                             <div class="form-check form-check-inline">
                             <label class="form-check-label" onclick="showInfo1()">
                                 <input type="radio" class="form-check-input" name="tutorType" value="1" checked> 
                                   In welk jaar  deed  je  <div style="text-align: center;">eindexamen?</div>
                             </label>
                             </div>
                            </div>
                        </div>
                        <div style="width: 38%;" class="col-sm-6">
                            <div class="reveal_additional_info">
                    <div class="add_info" id="info1">
                        <div class="form-group same_width">
                            <select class="form-control" id="select_class" name="class">
                                <option value="">Selecteer</option>
                                <?php
                                        for($i =2010; $i < 2019; $i++){
                                    ?>
                                    <option value="<?php echo e($i); ?>"> <?php echo e($i); ?></option>
                                    <?php } ?>
                            </select>
                            <!-- <?php if(Session::has('class') ): ?>
                                    <span style="color:red"><?php echo e(Session::get('class')); ?></span>
                                <?php endif; ?> -->

                        </div>
                    </div>
<!--cut-->
                </div>
                        </div>


                    </div>
                <div class="form-group">
                        <label for="email" class="input_title">Welke studie doe je nu?</label>
                        <input type="text" class="form-control" id="current_study" placeholder="Huidige studie" name="currentstudy"> 
                        
                </div>

                <div class="fixed_container">
                    <div class="row text-left">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="firstname" class="input_title">Voornaam</label>
                                <input type="text" class="form-control" id="firstname" placeholder="Voornaam" name="firstname" value="<?php echo e(old('firstname')); ?>">
                                <!-- <?php if($errors->has('firstname')): ?>
                                        <span style="color:red"> <?php echo e($errors->first('firstname')); ?></span>
                                     <?php endif; ?> -->
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="lastname" class="input_title">Achternaam</label>
                                <input type="text" class="form-control" id="lastname" placeholder="Achternaam" name="lastname" value="<?php echo e(old('lastname')); ?>">
                                <!-- <?php if($errors->has('lastname')): ?>
                                        <span style="color:red"> <?php echo e($errors->first('lastname')); ?></span>
                                     <?php endif; ?> -->
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="email" class="input_title">E-mailadres</label>
                        <input type="email" class="form-control" id="email" placeholder="E-mailadres" name="email" value="<?php echo e(old('email')); ?>">
                        <!-- <?php if($errors->has('email')): ?>
                                        <span style="color:red"> <?php echo e($errors->first('email')); ?></span>
                                     <?php endif; ?> -->
                    </div>
                    <div class="form-group">
                        <label for="telephone" class="input_title">Telefoonnummer</label>
                        <input type="tel" class="form-control" id="telephone" placeholder="Telefoonnummer" name="telephone" value="<?php echo e(old('telephone')); ?>">
                        <!-- <?php if($errors->has('telephone')): ?>
                                        <span style="color:red"> <?php echo e($errors->first('telephone')); ?></span>
                                     <?php endif; ?> -->
                    </div>
                    <div class="row text-left">
                        <div class="col-sm-7">
                            <div class="form-group">
                                <label for="street" class="input_title">Straat</label>
                                <input type="text" class="form-control" id="street" placeholder="Straat" name="street" value="<?php echo e(old('street')); ?>">
                                <!--  <?php if($errors->has('street')): ?>
                                        <span style="color:red"> <?php echo e($errors->first('street')); ?></span>
                                     <?php endif; ?> -->
                            </div>
                        </div>
                        <div class="col-sm-5">
                            <div class="form-group">
                                <label for="house_no" class="input_title">Huisnummer</label>
                                <input type="text" class="form-control" id="house_no" placeholder="Huisnummer" name="houseno" value="<?php echo e(old('houseno')); ?>">
                                <!-- <?php if($errors->has('houseno')): ?>
                                        <span style="color:red"> <?php echo e($errors->first('houseno')); ?></span>
                                     <?php endif; ?> -->
                            </div>
                        </div>
                    </div>
                    <div class="row text-left">
                        <div class="col-sm-5">
                            <div class="form-group">
                                <label for="postcode" class="input_title">Postcode</label>
                                <input type="text" class="form-control" id="postcode" placeholder="Postcode" name="tutorpostcode" value="<?php echo e(old('tutorpostcode')); ?>">
                                <!-- <?php if($errors->has('tutorpostcode')): ?>
                                        <span style="color:red"> <?php echo e($errors->first('tutorpostcode')); ?></span>
                                     <?php endif; ?> -->
                            </div>
                        </div>
                        <div class="col-sm-7">
                            <div class="form-group">
                                <label for="residence" class="input_title">Woonplaats</label>
                                <input type="text" class="form-control" id="residence" placeholder="Woonplaats" name="residence" value="<?php echo e(old('residence')); ?>">
                                <!-- <?php if($errors->has('residence')): ?>
                                        <span style="color:red"> <?php echo e($errors->first('residence')); ?></span>
                                     <?php endif; ?> -->
                            </div>
                        </div>
                    </div>
                    <div class="row text-left">
                        <div class="col-sm-7">
                            <div class="form-group">
                                <label for="date" class="input_title">Geboortedatum</label>
                                <input type="text" class="form-control" data-toggle="datepicker" placeholder="dd-mm-jjjj" name="birthdate" value="<?php echo e(old('birthdate')); ?>">
                                <!-- <?php if($errors->has('birthdate')): ?>
                                        <span style="color:red"> <?php echo e($errors->first('birthdate')); ?></span>
                                     <?php endif; ?> -->
                            </div>
                        </div>
                        <div class="col-sm-5">
                            <div class="form-group text-md-left text-center">
                                <label for="" class="input_title">Geslacht</label>
                                <div class="form-check">
                                    <label class="form-check-label">
                                        <input type="radio" class="form-check-input" name="gender" value="Man" checked> Man
                                    </label>
                                </div>
                                <div class="form-check">
                                    <label class="form-check-label">
                                        <input type="radio" class="form-check-input" name="gender" value="Vrouw"> Vrouw
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
                <div class="text-center"><a href="#"><button style="border:0px;background-color: #4391F2;" type="button" class="btn btn-success">Wijzig</button></a></div>
        </section>
    </div>
    <div class="col-sm-2"></div>
</div> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/adminn/style.css' )); ?>">
<?php $__env->stopSection(); ?>


<?php echo $__env->make('tutor.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
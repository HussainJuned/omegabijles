<div class="container-fluid">
        <header class="site_top">
            <div class="inner_bg">
                <nav class="navbar navbar-expand-md navbar_custom navbar-dark dpadding">
                    <!-- Brand -->
                    <a class="navbar-brand" href="index.html"><img src="<?php echo e(asset('public/frontEnd/img/icons/logo_w@3x.svg')); ?>" alt="Logo"></a>
                    <!-- Toggler/collapsibe Button -->
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <!-- Navbar links -->
                    <div class="collapse navbar-collapse navbar_flexend" id="collapsibleNavbar">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="index.html">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="how_it_works.html">Hoe het werkt</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="contact.html">Contact</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="becomeTutor.blade.php">Word bijlesgever</a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <div class="intro_text dpadding">
                    <h1>Vind snel en gemakkelijk de bijlesgever die bij je past</h1>
                    <h4>Krijg bijles van een (oud-)leerling die bij je past en zie dat je vooruit gaat.</h4>
                    <div class="search_box">
                        <form class="search_form">
                            <select class="selections" name="subject">
                                <option value="Empty">Vak</option>
                                <option value="Aardrijkskunde">Aardrijkskunde</option>
                                <option value="Biologie">Biologie</option>
                                <option value="Duits">Duits</option>
                                <option value="Economie">Economie</option>
                                <option value="Engels">Engels</option>
                                <option value="Filosofie">Filosofie</option>
                                <option value="Frans">Frans</option>
                                <option value="Geschiedenis">Geschiedenis</option>
                                <option value="Grieks">Grieks</option>
                                <option value="Latijn">Latijn</option>
                                <option value="Maatschappijleer">Maatschappijleer</option>
                                <option value="Natuurkunde">Natuurkunde</option>
                                <option value="Nederlands">Nederlands</option>
                                <option value="NLT">NLT</option>
                                <option value="Scheikunde">Scheikunde</option>
                                <option value="Wiskunde (onderbouw)">Wiskunde (onderbouw)</option>
                                <option value="Wiskunde A">Wiskunde A</option>
                                <option value="Wiskunde B">Wiskunde B</option>
                                <option value="Wiskunde C">Wiskunde C</option>
                            </select>
                            <input type="text" name="postcode" placeholder="Postcode  bijv ‘1011AA’">
                            <button type="submit" name="submit_btn" class="btn submit_btn">Zoeken</button>
                        </form>
                        <h6>Kies uit +20 bijlesgevers die jouw school kennen</h6>
                    </div>
                </div>
            </div>
        </header>
        <nav class="navbar navbar-expand-lg  navbar-dark navbar_lang">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="#">Engels</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Natuurkunde</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Wiskunde</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Latijn</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Grieks</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Scheikunde</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Frans</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Duits</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Biologie</a>
                </li>
            </ul>
        </nav>
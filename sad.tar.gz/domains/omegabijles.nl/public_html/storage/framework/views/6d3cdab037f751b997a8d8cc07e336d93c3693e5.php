<h3>You have  a new email for Checking availibility of  <a href="<?php echo e(url('/tutorprofile/')); ?>/<?php echo e($tutor->user_id); ?>"><?php echo e($tutor->firstname . ' ' . $tutor->lastname); ?></a></h3>
<div>
	<h5>Sender Message: </h5>
	<ul>
		<li>Name: <?php echo e($data->name); ?></li>
		<li>email : <?php echo e($data->email); ?></li>
		<li>Tutor Type : <?php echo e($data->tutortype); ?></li>
		<li>Description: <?php echo e($data->description); ?></li>
	</ul>
</div>
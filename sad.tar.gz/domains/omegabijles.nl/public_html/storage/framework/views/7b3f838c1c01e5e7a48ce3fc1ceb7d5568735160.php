<?php $__env->startSection('title'); ?>
    Change Password
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mainContent'); ?>
<style type="text/css">
    .help-block{
        color:red;
    }
</style>
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-1"></div>
            <div class="col-md-10">
                <div class="box box-primary">
                    <div class="box-header text-center">
                        <h3 class="box-title">Verander wachtwoord</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->

                     <form role="form" method="post" action="<?php echo e(url('/admin/changepass')); ?>">
                        <?php echo e(csrf_field()); ?>

                         <div class="box-body">
                            <div class="form-group">
                                <label for="old_password">Oud wachtwoord</label>
                                <input type="password" class="form-control" id="old_password" name="old_password">
                                <?php if($errors->has('old_password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('old_password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                <?php if( Session::has('mismatch') ): ?>
                                    <span class="help-block">
                                        <strong><?php echo e(Session::get('mismatch')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div><!-- /.box-body -->
                        <div class="box-body">
                            <div class="form-group">
                                <label for="new_password">Nieuw wachtwoord</label>
                                <input type="password" class="form-control" id="new_password" name="new_password">
                                <?php if($errors->has('new_password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('new_password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div><!-- /.box-body -->
                        <div class="box-body">
                            <div class="form-group">
                                <label for="confirm_password">Bevestig nieuw wachtwoord</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                                <?php if($errors->has('confirm_password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('confirm_password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div><!-- /.box-body -->
                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Verander wachtwoord</button>
                        </div>
                    </form>
                </div><!-- /.box -->
            </div>
            <div class="col-md-1"></div>
        </div>
    </section> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
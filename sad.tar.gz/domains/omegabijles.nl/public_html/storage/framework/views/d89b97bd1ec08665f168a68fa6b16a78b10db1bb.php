<div class="collapse navbar-collapse navbar_flexend" id="collapsibleNavbar">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/howitworks')); ?>">Hoe het werkt</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/contact')); ?>">Contact</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/becomeatutor')); ?>">Word bijlesgever</a>
                            </li>
                        </ul>
                    </div>
<?php $__env->startSection('content'); ?>
                 <br>
                 <div class="flash-message">
                         <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <?php if(Session::has('alert-' . $msg)): ?>
                         <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                          <?php endif; ?>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </div>
	<section class="contact_us">
            <h2>Neem contact op</h2>
            <p>Kunnen we ergens bij helpen? Dan horen we het graag! We streven ernaar binnen 24 uur je bericht te beantwoorden.</p>
            <h3>Gebruik het onderstaande formulier:</h3>
            <form action="<?php echo e(url('/contact')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <input type="text" name="name" placeholder="Uw naam" class="form-control">
                <?php if($errors->has('name')): ?>
                    <span style="color:red">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                <?php endif; ?>
                 <input type="text" name="email" placeholder="Uw E-mailadres" class="form-control">
                <?php if($errors->has('email')): ?>
                    <span style="color:red">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
                  <input type="text" name="phone" placeholder="Uw Telefoonnummer (optioneel)" class="form-control">
                <?php if($errors->has('phone')): ?>
                    <span style="color:red">
                        <strong><?php echo e($errors->first('phone')); ?></strong>
                    </span>
                <?php endif; ?>
                <input type="text" name="subject" placeholder="Onderwerp" class="form-control">
                <?php if($errors->has('subject')): ?>
                    <span style="color:red">
                        <strong><?php echo e($errors->first('subject')); ?></strong>
                    </span>
                <?php endif; ?>
                <textarea name="message" rows="8" cols="80" placeholder="Bericht" class="form-control"></textarea>
                <?php if($errors->has('message')): ?>
                    <span style="color:red">
                        <strong><?php echo e($errors->first('message')); ?></strong>
                    </span>
                <?php endif; ?>
                <button type="submit" class="btn btn2 btn-block">Verstuur</button>
            </form>
            <p class="centerized">
                <a href="#">Liever meteen geholpen worden? Chat dan live met ons.</a>
            </p>
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
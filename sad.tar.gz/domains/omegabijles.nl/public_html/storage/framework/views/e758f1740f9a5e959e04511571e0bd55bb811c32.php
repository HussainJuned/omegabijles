<?php $__env->startSection('css'); ?>
     <link rel="stylesheet" href="<?php echo e(URL::to('public/frontEnd/css/tutor_profile.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="dpadding">
        <div class="back_text">
            <a href="search_profile.html"><i class="fas fa-long-arrow-alt-left"></i> <span> Terug naar resultaten</span></a>
        </div>
        <div class="my_card">
            <div class="row">
                <div class="col-lg-8 col-md-8">
                    <div class="row">
                        <div class="col-lg-4 profile_image">
                            <img src="<?php echo e(URL::to('public/uploads')); ?>/<?php echo e($tutorInfo->image); ?>" alt="profile image">
                        </div>
                        <div class="col-lg-8 profile_title">
                            <div class="row">
                                <div class="col-md-8 name_tutor text-center text-md-left">
                                    <h1><?php echo e($tutorInfo->firstname); ?></h1>
                                    <div class="star_ratings">
                                        <i class="fas fa-star checked"></i>
                                        <i class="fas fa-star checked"></i>
                                        <i class="fas fa-star checked"></i>
                                        <i class="fas fa-star checked"></i>
                                        <i class="fas fa-star checked"></i>
                                    </div>
                                    <div class="tutor_icons text-left">
                                        <?php if($tutorInfo->tutor_type == 1): ?>
                                        <div class="ti_box"><img src="<?php echo e(URL::to('public/frontEnd/img/icons/graduation-cap.svg')); ?>" alt="icon" style="width: 16px"> <span>Leering klas <?php echo e($tutorInfo->current_class_for_student); ?> </span></div>
                                        <?php endif; ?>
                                         <?php if($tutorInfo->tutor_type == 2): ?>
                                        <div class="ti_box"><img src="<?php echo e(URL::to('public/frontEnd/img/icons/graduation-cap.svg')); ?>" alt="icon" style="width: 16px"> <span>Oud-Leerling </span></div>
                                        <?php endif; ?>
                                        <div class="ti_box"><img src="<?php echo e(URL::to('public/frontEnd/img/icons/badge.svg')); ?>" alt="icon" style="width: 12px"> <span>Geselecteerd en getraind</span></div>
                                        <div class="ti_box"><img src="<?php echo e(URL::to('public/frontEnd/img/icons/seccess.svg')); ?>" alt="icon" style="width: 14px"> <span>Niet blij met de eerste les? Dan geld terug</span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="left_content">
                        <h3>Introductie</h3>
                        <p><?php echo e($tutorInfo->Briefintroduction); ?></p>
                        <h3>Hoe ik je help</h3>
                        <p><?php echo e($tutorInfo->helpthestudent); ?>

                        </p>
                        <h3>Meer over mij</h3>
                        <p><?php echo e($tutorInfo->abitmore); ?>

                        </p>
                        <div class="single_block">
                            <h3>Ervaring met</h3>
                            <div class="row tabular">
                                <div class="col-sm-6 left_cell">
                                    <p>Hoogbegaafdheid:</p>
                                </div>
                                <div class="col-sm-6 right_cell">
                                    <p><?php echo e($tutorExperience->experiencewithgiftedness); ?></p>
                                </div>
                            </div>
                            <div class="row tabular">
                                <div class="col-sm-6 left_cell">
                                    <p>ADD/ PDD NOS:</p>
                                </div>
                                <div class="col-sm-6 right_cell">
                                    <p><?php echo e($tutorExperience->experiencewithaddpdd); ?></p>
                                </div>
                            </div>
                            <div class="row tabular">
                                <div class="col-sm-6 left_cell">
                                    <p>ADHD:</p>
                                </div>
                                <div class="col-sm-6 right_cell">
                                    <p><?php echo e($tutorExperience->experiencewithadhd); ?></p>
                                </div>
                            </div>
                            <div class="row tabular">
                                <div class="col-sm-6 left_cell">
                                    <p>Autisme:</p>
                                </div>
                                <div class="col-sm-6 right_cell">
                                    <p><?php echo e($tutorExperience->experiencewithautisme); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="single_block">
                            <h3>Vakken</h3>
                            <?php $__currentLoopData = $tutorCourse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row tabular">
                                <div class="col-sm-6 left_cell">
                                    <p><?php echo e($val->coursename); ?>:</p>
                                </div>
                                <div class="col-sm-6 right_cell">
                                    <p>klas <?php echo e($val->classes); ?></p>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="single_block">
                            <h3>Mijn beschikbaarheid</h3>
                            <div class="row tabular">
                                <div class="col-sm-6 left_cell">
                                    <p>Maandag:</p>
                                </div>
                                <div class="col-sm-6 right_cell">
                                    <p><?php echo e($tutorTime->mon != null?$tutorTime->mon:'-'); ?></p>
                                </div>
                            </div>
                            <div class="row tabular">
                                <div class="col-sm-6 left_cell">
                                    <p>Dinsdag:</p>
                                </div>
                                <div class="col-sm-6 right_cell">
                                    <p><?php echo e($tutorTime->tue != null?$tutorTime->tue:'-'); ?></p>
                                </div>
                            </div>
                            <div class="row tabular">
                                <div class="col-sm-6 left_cell">
                                    <p>Woensdag:</p>
                                </div>
                                <div class="col-sm-6 right_cell">
                                    <p><?php echo e($tutorTime->wed != null?$tutorTime->wed:'-'); ?></p>
                                </div>
                            </div>
                            <div class="row tabular">
                                <div class="col-sm-6 left_cell">
                                    <p>Donderdag:</p>
                                </div>
                                <div class="col-sm-6 right_cell">
                                    <p><?php echo e($tutorTime->thus != null?$tutorTime->thus:'-'); ?></p>
                                </div>
                            </div>
                            <div class="row tabular">
                                <div class="col-sm-6 left_cell">
                                    <p>Vrijdag:</p>
                                </div>
                                <div class="col-sm-6 right_cell">
                                    <p><?php echo e($tutorTime->fri != null?$tutorTime->fri:'-'); ?></p>
                                </div>
                            </div>
                            <div class="row tabular">
                                <div class="col-sm-6 left_cell">
                                    <p>Zaterdag:</p>
                                </div>
                                <div class="col-sm-6 right_cell">
                                    <p><?php echo e($tutorTime->sat != null?$tutorTime->sat:'-'); ?></p>
                                </div>
                            </div>
                            <div class="row tabular">
                                <div class="col-sm-6 left_cell">
                                    <p>Zondag:</p>
                                </div>
                                <div class="col-sm-6 right_cell">
                                    <p><?php echo e($tutorTime->sun != null?$tutorTime->sun:'-'); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="single_block">
                            <h3>Ervaringen</h3>
                            <div class="standout_review">
                                <span class="standout">5/5</span>
                                <span class="inline_ratings">
                                    <i class="fas fa-star checked"></i>
                                    <i class="fas fa-star checked"></i>
                                    <i class="fas fa-star checked"></i>
                                    <i class="fas fa-star checked"></i>
                                    <i class="fas fa-star checked"></i>
                                </span>
                                <span class="small_text">op basis van 3 reviews</span>
                            </div>
                            <div class="curricullar_reviews text-lg-left">
                                <div class="row mb-3">
                                    <div class="col text-lg-right">
                                        <div class="row no-gutters">
                                            <div class="col-lg-7 text-lg-right">
                                                <span class="review_title">De bijlesgever heeft mij goed geholpen</span>
                                            </div>
                                            <div class="col-lg-5 text-lg-right">
                                                <span class="inline_ratings">
                                                    <i class="fas fa-star checked"></i>
                                                    <i class="fas fa-star checked"></i>
                                                    <i class="fas fa-star checked"></i>
                                                    <i class="fas fa-star checked"></i>
                                                    <i class="fas fa-star"></i>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col text_left">
                                        <span class="review_cmt col-lg-6"><strong>Title Review</strong> Door Jenela op 24-02-27</span>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col text-lg-right">
                                        <div class="row no-gutters">
                                            <div class="col-lg-7 text-lg-right">
                                                <span class="review_title">De bijlesgever is prettig om mee te werken</span>
                                            </div>
                                            <div class="col-lg-5 text-lg-right">
                                                <span class="inline_ratings">
                                                    <i class="fas fa-star checked"></i>
                                                    <i class="fas fa-star checked"></i>
                                                    <i class="fas fa-star checked"></i>
                                                    <i class="fas fa-star checked"></i>
                                                    <i class="fas fa-star"></i>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col text_left">
                                        <span class="review_cmt"> more text more text</span>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col text-lg-right">
                                        <div class="row no-gutters">
                                            <div class="col-lg-7 text-lg-right">
                                                <span class="review_title">Ik beveel de bijlesgever aan</span>
                                            </div>
                                            <div class="col-lg-5 text-lg-right">
                                                <span class="inline_ratings">
                                                    <i class="fas fa-star checked"></i>
                                                    <i class="fas fa-star checked"></i>
                                                    <i class="fas fa-star checked"></i>
                                                    <i class="fas fa-star checked"></i>
                                                    <i class="fas fa-star"></i>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col text_left">
                                        <span class="review_cmt">more text textmore textmore</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="single_block">
                            <h5>Schirf en review</h5>
                            <form class="review_form">
                                <input type="text" name="name" placeholder="Input Value" class="form_control">
                                <input type="email" name="email" placeholder="Input Value" class="form_control">
                                <textarea placeholder="Text Area Content" name="textarea" class="form_control"></textarea>
                                <button type="submit" class="btn btn-primary">Verstur Review</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="sticky-top right_side">
                        <div class="price text-center text-md-left">
                            <h4 data-toggle="modal" data-target="#priceModal">&euro;18,<span>- p/u</span></h4>
                        </div>
                        <div class="right_content">
                            <h3>Neem contact op met deze bijlesgever</h3>
                            <form class="contact_form">
                                <input type="text" name="name2" placeholder="Naam" class="form_control">
                                <input type="text" name="name3" placeholder="Emailadres" class="form_control">
                                <div class="form-check text-left">
                                    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios3" value="option1" checked>
                                    <label class="form-check-label" for="exampleRadios3">
                                        Ik ben een leerling
                                    </label>
                                </div>
                                <div class="form-check text-left mb-3">
                                    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios4" value="option2">
                                    <label class="form-check-label" for="exampleRadios4">
                                        Ik ben een ouder
                                    </label>
                                </div>
                                <textarea placeholder="Bericht" name="textarea2" class="form_control"></textarea>
                                <button type="submit" class="btn btn-availability btn-block pl-0 pr-0">Check beschikbaarheid</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <div class="fixed_button dpadding">
        <div class="beng">
            <div class="price text-left">
                <h4 data-toggle="modal" data-target="#priceModal">&euro;18,<span>- p/u</span></h4>
            </div>
        </div>
        <div class="beng">
            <button type="button" class="btn btn-availability" data-toggle="modal" data-target="#myModal">
                Check beschikbaarheid
            </button>
        </div>
    </div>
    <!-- The Modal -->
    <div class="modal fade" id="myModal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h3 class="modal-title">Neem contact op met deze bijlesgever</h3>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <form class="contact_form">
                        <input type="text" name="name2" placeholder="Naam" class="form_control">
                        <input type="text" name="name3" placeholder="Emailadres" class="form_control">
                        <div class="form-check text-left">
                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                            <label class="form-check-label" for="exampleRadios1">
                                Ik ben een leerling
                            </label>
                        </div>
                        <div class="form-check text-left mb-3">
                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="option2">
                            <label class="form-check-label" for="exampleRadios2">
                                Ik ben een ouder
                            </label>
                        </div>
                        <textarea placeholder="Bericht" name="textarea2" class="form_control"></textarea>
                        <button type="submit" class="btn btn-availability btn-block pl-0 pr-0">Check beschikbaarheid</button>
                    </form>
                </div>
                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Sluiten</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="priceModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Prijzen info</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <P>Het uurtarief voor een leerling bedraagt €10,- p/u en voor een oud-leerling/student is dit €18,- p/u. U betaalt maandelijks achteraf gemakkelijk en veilig via iDeal.</P>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Sluiten</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 


<?php $__env->startSection('mainContent'); ?>

 <div class="row">
    <div class="col-sm-2"></div>
    <div style="background-color: white;margin-bottom: 80px !important;" class="col-sm-8">
        <section class="content">

                <h2 style="text-align: left;font-size: 23px;font-weight: 600;" class="fs-title edit-info2">Fijn dat je er weer bent!  😄</h2>
                <p style="margin-bottom: 30px;font-size: 18px;margin-top: 11px;" class="fs-very-small dash4">Gebruik het menu hiernaast of navigeer snel naar:</p>
                
                <div class="dpadding">
                    <div class="row mb-4">
                        <a href="<?php echo e(url('/tutor/email')); ?>"><div class="col-md-4 dash1 dash2">
                            <h3 class="dash5"><i class="fa fa-envelope dash6"></i></h3>
                            <p class="mb-5 dash7">Email </p>
                        </div></a>

                        <a href="<?php echo e(url('/tutor/uren')); ?>"><div class="col-md-4 dash1 dash2">
                            <h3 class="dash5"><i class="fa fa-clock-o dash6"></i></h3>
                            <p class="mb-5 dash7">Uren </p>
                        </div></a>
                        
                    </div>
                    <div class="row">
                        <a href="<?php echo e(url('/tutor/evaluatie')); ?>"><div class="col-md-4 dash1 dash2 dash9">
                            <h3 class="dash5"><i class="fa fa-check dash6"></i></h3>
                            <p class="mb-5 dash7 ">Evaluatie </p>
                        </div></a>
                        <a href="<?php echo e(url('/tutor/documenten')); ?>"><div class="col-md-4 dash1 dash2">
                            <h3 class="dash5"><i class="fa fa-file dash6"></i></h3>
                            <p class="mb-5 dash7">Documenten </p>
                        </div></a>
                        
                    </div>
                </div>
                <?php if(auth()->guard()->check()): ?>
                <div class="text-center"><a href="<?php echo e(url('/tutorprofile/')); ?>/<?php echo e(Auth::user()->id); ?>" target="_blank"><button style="border:0px;background-color: #4391F2;margin-bottom: 10px;" type="button" class="btn btn-success dash10">Bekijk mijn profiel</button></a></div>

                <p style="margin-bottom: 30px;font-size: 18px;margin-top: 11px;" class="fs-very-small dash8">Als je vragen hebt, stuur ons dan vooral even een berichtje.</p>
                <?php endif; ?>
        </section>
    </div>
    <div class="col-sm-2"></div>
</div> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/adminn/style.css' )); ?>">
<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('tutor.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
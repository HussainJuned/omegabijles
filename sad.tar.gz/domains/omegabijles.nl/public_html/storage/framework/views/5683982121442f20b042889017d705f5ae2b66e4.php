 


<?php $__env->startSection('mainContent'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/adminn/style.css')); ?>">
 <div class="row">
    <div class="col-sm-2"></div>
    <div style="background-color: white;margin-bottom: 80px !important;" class="col-sm-8 profiel6">
        <div  class="fixed_container vakken6 ">
                        <!-- <?php if($errors->has('course')): ?>
                        <span style="color:red"> <?php echo e($errors->first('course')); ?></span>
                     <?php endif; ?> -->
                     <div class="text-right pull-right vakken9"><a href="#"><button style="border:0px;background-color: #4391F2;margin-bottom: 10px;" type="button" class="btn btn-success profiel4">Wijzig</button></a></div>
                        <h2 style="margin-left: 19px;margin-bottom:30px;text-align:left; font-size: 24px;font-weight: 600;" class="fs-title profiel7">Mijn vakken
                            
                        </h2>
                        <p style="margin-bottom: 20px;font-size: 14px;" class="fs-very-small vakken8">Je kunt bijlesgeven in de vakken waar je minimaal een 7,5 gemiddeld hebt gehaald</p>
                    </div>
                    <div style="margin-left: 8px;" class="row mb-3 d-none d-sm-flex vakken3">
                        <div class="col-sm-5 text-center">
                            <label class="input_title vakken3">Mijn Vakken:</label>
                        </div>
                        <div class="col-sm-5 text-left">
                            <label class="input_title vakken3">Op welk niveau</label>
                        </div>
                        <div class="col-sm-2 bottom-right"></div>
                    </div>
                    <div id="course_container">
                        <div class="row course">
                            <div class="col-sm-5 text-center vakken4">
                                <h3>Wiskunde A</h3>
                            </div>
                            <div class="col-sm-7">
                                <div class="row">
                                    <div style="margin-top: 15px;" class="col-sm-7 text-md-left mb-3 vakken">
                                        <?php for($i=1; $i < 7; $i++){ ?>
                                        <div style="margin-bottom: 5px;" class="col-sm-7 text-md-left mb-3">
                                            <div class="form-check">
                                                <label class="form-check-label">
                                                    <input class="form-check-input" type="checkbox" name="course[Wiskunde A][]" value="<?php echo e($i); ?>"> Klas <?php echo e($i); ?>

                                                </label>
                                            </div>
                                        </div>
                                        <?php } ?>
                                    </div>
                                    <div class="col-sm-5 bottom-right mb-3">Verwijder vak <img src="<?php echo e(URL::to('public/frontEnd/img/icons/remove.svg')); ?>" alt="delete" class="small_icon"></div>
                                </div>
                            </div>
                        </div>
                        <div class="row course">
                            <div class="col-sm-5 text-center vakken4">
                                <h3>Wiskunde B</h3>
                            </div>
                            <div class="col-sm-7">
                                <div class="row">
                                    <?php for($i=1; $i < 7; $i++){ ?>
                                    <div style="margin-top: 14px;" class="col-sm-7 text-md-left mb-3 text-lg-left vakken2">
                                        <div class="form-check">
                                            <label class="form-check-label">
                                                <input class="form-check-input" type="checkbox" name="course[Wiskunde B][]" value="<?php echo e($i); ?>"> Klas <?php echo e($i); ?>

                                            </label>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    <div class="col-sm-5 bottom-right mb-3">Verwijder vak <img src="<?php echo e(URL::to('public/frontEnd/img/icons/remove.svg')); ?>" alt="delete" class="small_icon"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                <div class="text-center vakken5"><a href="#"><button style="border:0px;background-color: #4391F2;margin-bottom: 10px;" type="button" class="btn btn-success">Wijzig</button></a></div>
        
    </div>
    <div class="col-sm-2"></div>
</div> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/adminn/style.css' )); ?>">
<?php $__env->stopSection(); ?>


<?php echo $__env->make('tutor.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
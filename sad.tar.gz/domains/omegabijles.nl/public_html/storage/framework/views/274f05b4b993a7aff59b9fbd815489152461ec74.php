<h3>You have  a new contact via Contact form</h3>
<div>
	<?php echo e($bodyMessage); ?>

</div>
<p>sent via <?php echo e($email); ?> </p>
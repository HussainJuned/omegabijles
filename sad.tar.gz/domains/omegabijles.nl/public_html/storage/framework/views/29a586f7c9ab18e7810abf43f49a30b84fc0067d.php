

<?php $__env->startSection('content'); ?>
<style type="text/css">
  .help-block{
    color:red;
  }
</style>
                 <section class="pt-5 pb-5">
            <div class="fixed_container text-center">
                <h2>Login</h2>

                <div class="login_img_container">
                    <img src="<?php echo e(URL::to('public/frontEnd/img/icons/images-128x128.png')); ?>" alt="fav icon" class="img-fluid">
                </div>
                <form class="mt-5 mb-5" method="POST" action="<?php echo e(url('/tutor/login')); ?>">
                  <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <input type="email" class="form-control" name="email" id="email" placeholder="E-mailadres">
                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?> 
                        <?php if( Session::has('error') ): ?>
                                    <span class="help-block">
                                        <strong><?php echo e(Session::get('error')); ?></strong>
                                    </span>
                                <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" name="password" id="pwd" placeholder="Wachtwoord">
                        <?php if($errors->has('password')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?> 
                    </div>
                    <div class="form-check text-left mb-5">
                        <label class="form-check-label">
                            <input class="form-check-input" type="checkbox" name="remember" value="1"> Onthoud mijn gegevens

                        </label>
                    </div>
                    <button type="submit" class="btn btn2 btn-block">Login</button>
                    <ul class="login-more text-left">
                        <li>
                            <span>Wachtwoord</span>
                            <a href="<?php echo e(url('/tutor/forget-password')); ?>" class="underline"> Vergeten?</a>
                        </li>
                       
                    </ul>
                </form>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TutorCourse extends Model
{
    protected $table = 'tutorcourse';
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TutorTime extends Model
{
    protected $table = 'tutortotime';
}

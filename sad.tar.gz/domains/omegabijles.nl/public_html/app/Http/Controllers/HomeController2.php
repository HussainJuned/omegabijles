<?php

namespace App\Http\Controllers;

use App\TutorReview;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Post;
use Session;
use App\User;
use App\TutorCourse;
use App\TutorExperience;
use App\TutorInfo;
use App\Tutorsearch;
use App\TutorTime;
use App\Postcode;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;
use App\Mail\ContactTutorMail;
use Illuminate\Support\Facades\Mail;
class HomeController extends Controller
{
    
    public function index(){
        return view('frontEnd.home.homeContent');
    }
    public function getContact(){
    	return view('frontEnd.home.contact');
    }
    public function postContact(Request $request){
        $this->validate($request, [
             'name'   => 'required|min:4',
             'subject'=>'required|min:3',
             'email'  => 'required|email',
             'phone'  => '',
             'message'=> 'required|min:10'
             ],
             ['name.required' => 'Dit veld mag niet leeg zijn!',
              'name.min' => 'moet minimaal 4 tekens lang zijn!',
              'subject.required' => 'Dit veld mag niet leeg zijn!',
              'subject.min' => 'moet minimaal 3 tekens lang zijn!',
              'email.required' => 'Dit veld mag niet leeg zijn!',
              'email.email' => 'moet een e-mail zijn!',
              'message.required' => 'Dit veld mag niet leeg zijn!',
              'message.min' => 'moet minimaal 10 tekens lang zijn!'
                 ]);
        $data = array(
            'name'=> $request->name,
            'subject'=> $request->subject,
            'email'=> $request->email,
            'Phone' => $request->phone,
            'bodyMessage'=> $request->message
             );

        Mail::send('emails.contactForm', $data, function($message) use($data) {
            $message->from($data['email']);
            $message->to('omegabijles@gmail.com');
            $message->subject($data['subject']);
        });
    $request->session()->flash('alert-success', 'Uw e-mail is met succes verzonden!');
        return redirect('/contact');
    }


    public function howitworks(){
    	return view('frontEnd.home.howitworks');
    }

    public function becomeatutor(){
    	return view('frontEnd.home.becomeatutor');
    }

    public function tutorprofile($id){
        $users = User::find($id);
        $tutorInfo = TutorInfo::where(['user_id' => $id])->first();
        $tutorCourse = TutorCourse::where(['user_id' => $id])->get();
        $tutorExperience = TutorExperience::where(['user_id' => $id])->first();
        $tutorTime = TutorTime::where(['user_id' => $id])->first();

        $ratings = TutorReview::where('user_id', $id)->latest()->get();

		    $avg_rating = DB::table('tutoravgrating')->where(['user_id' => $id])->first();
        if($avg_rating){
          $avg_rating = round($avg_rating->avgrating);
        }else{
          $avg_rating = 0;
        }
        return view('frontEnd.home.tutorprofile', compact('users','tutorInfo','tutorCourse','tutorExperience','tutorTime', 'avg_rating', 'ratings'));
    }
    

    public function applytutorsuccess(){
      return view('frontEnd.home.applytutorsuccess');
    }

	public function search( $postcode, $subject ) {
		$tutorinfo = null;


		if ( $postcode != null && $subject != null ) {
      $postcodes = new Postcode();
			$singlepost = $postcodes->checkAndUpdatePostcode($postcode);

			if ($singlepost != false) {

			$current_lat             = $singlepost->lat;
			$current_lng             = $singlepost->lng;
			$postlistarray   = [];
			$postlistarray[] = $postcode;
			// $postlist        = DB::select( "SELECT *,( 6371 * acos( cos( radians('$lat') ) * cos( radians( `lat` ) ) * cos( radians( `lng` ) -radians('$lng') ) +sin( radians('$lat') ) * sin( radians( `lat` ) ) ) ) AS distance FROM `postcode` HAVING distance <= 7 ORDER BY distance ASC" );

      $postlist = DB::select("SELECT postcode , (
                              6371 * acos (
                              cos ( radians('$current_lat') )
                              * cos( radians( lat ) )
                              * cos( radians( lng ) - radians('$current_lng') )
                              + sin ( radians('$current_lat') )
                              * sin( radians( lat ) )
                              )) AS distance from postcode HAVING distance <= 7 ORDER BY distance ASC");
      dd($postlist);
			if ( count( $postlist ) <= 0 ) {
				return view( 'frontEnd.home.search_profile', compact( 'tutors', 'tutorinfo' ) );
			}
			foreach ( $postlist as $value ) {
				$postlistarray[] = $value->postcode;
			}
      Session::put('postlist', $postlistarray);

      // $tutorinfo = Tutorinfo::whereIn( 'postalcode',$postlistarray)->paginate(2);
			$tutorinfo = DB::table('tutorinfo')->select('tutorinfo.*','tutorexperience.*','coursesnames.coursename','tutortotime.*', 'tutoravgrating.avgrating')
                  ->join('tutorexperience','tutorexperience.user_id','=','tutorinfo.user_id')
                  ->join('coursesnames','coursesnames.user_id','=','tutorinfo.user_id')
                  ->join('tutortotime','tutortotime.user_id','=','tutorinfo.user_id')
                  ->leftjoin('tutoravgrating','tutoravgrating.user_id','=','tutorinfo.user_id')
                  ->whereIn('tutorinfo.postalcode',$postlistarray)->orderBy('tutorinfo.id','DESC')->paginate(2);                                          
      $tutorsearch = new Tutorsearch();
      $tutorsearch->saveTutorSearch($postcode, $subject);
			return view( 'frontEnd.home.search_profile', compact('tutorinfo' ) );

		} else {
			return view( 'frontEnd.home.search_profile', compact('tutorinfo' ) );
		}
	}else{
    return redirect('/');
  }
}

public function filterData(Request $request) {
  $tutorinfo = new TutorInfo();
  $data = $tutorinfo->searchFilter($request);
  return $data;
}


public function contactTutor(Request $request) {
    $this->validate($request, [
            'name' => 'required|max:50',
            'email' => 'required|email|max:50',
            'tutortype' => 'required',
            'tutorid' => 'required',
            'description' => 'required',
        ],
        [
          'name.required' => 'naam is vereist!',
          'name.max' => 'naam mag niet langer zijn dan 50 tekens!',
          'email.required' => 'E-mailadres is vereist!',
          'email.email' => 'Moet een geldig e-mail adres zijn!',
          'tutortype.required' => 'leermeester is vereist',
          'description.required' => 'Beschrijving is vereist'
        ]);
        try{
          $tutor = TutorInfo::where(['id' => $request->tutorid])->first();
          Mail::to('info@omegabijles.nl')->send(new ContactTutorMail($request, $tutor));
          Session::flash('tsuccess','Er is een e-mail verzonden naar de beheerder met succes');
          return back();
          
        }catch(Exception $e){
          // dd($e);
          Session::flash('terror','Er ging iets fout, probeer opnieuw');
          return back();
        }
}

}

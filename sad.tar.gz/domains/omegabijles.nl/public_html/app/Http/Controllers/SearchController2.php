<?php

namespace App\Http\Controllers;

use App\TutorInfo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SearchController extends Controller
{
    public function index() {
		$tutorinfo = DB::table('tutorinfo')->select('tutorinfo.*','tutorexperience.*','coursesnames.coursename','tutortotime.*', 'tutoravgrating.avgrating')
                  ->join('tutorexperience','tutorexperience.user_id','=','tutorinfo.user_id')
                  ->join('coursesnames','coursesnames.user_id','=','tutorinfo.user_id')
                  ->join('tutortotime','tutortotime.user_id','=','tutorinfo.user_id')
                  ->leftjoin('tutoravgrating','tutoravgrating.user_id','=','tutorinfo.user_id')
                  ->orderBy('tutorinfo.id','DESC')
                  ->paginate(2);
		$total = count( $tutorinfo );
	    return view('frontEnd.home.search_profile', compact( [ 'tutorinfo', 'total' ]));
    }
}

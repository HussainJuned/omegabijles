var count=0;
jQuery(document).ready(function($) {

	$('#next_step').click(function(event) {

		if (count<3) {count++;}

		$('#next_step').removeClass('button-normals')
		if (count==1) {

			$('.eventwhen').addClass('active');
			$('.step_about').addClass('active');
			$('.second-d-none').addClass('second-d-block');
			$('.col-abc').addClass('col-abc1');

			$('.step_categories').removeClass('active');
			
		}
		if (count==2) {
			$('.eventwhere').addClass('active');

			$('.step_dates').addClass('active');

			$('.step_categories').removeClass('active');

			$('.step_about').removeClass('active');
			$('.step_times').removeClass('active');
		}

		if (count==3) {
			$('.eventwho').addClass('active');

			$('.step_times').addClass('active');

			$('.step_categories').removeClass('active');

			$('.step_about').removeClass('active');
			$('.step_dates').removeClass('active');

			$('#next_step').addClass('button-normals')
		}

	});

	$('#previous_step').click(function(event) {
		if (count>0) {count--;}

		$('#next_step').removeClass('button-normals')
		
		if (count==2) {

			$('.eventwhere').addClass('active');

			$('.step_dates').addClass('active');

			$('.step_categories').removeClass('active');

			$('.step_locations').removeClass('active');
			$('.eventwho').removeClass('active');
			
		}

		if (count==1) {

			$('.eventwhen').addClass('active');
			$('.step_about').addClass('active');
			
			$('.col-abc').addClass('col-abc1');
			

			$('.step_dates').removeClass('active');
			$('.eventwhere').removeClass('active');

			$('.previous_step').addClass('second-d-none');

		}

		if (count==0) {
			$('.second-d-none').removeClass('second-d-block');
			$('.step_categories').addClass('active')
			$('.step_categories').addClass('active')

			$('.step_about').removeClass('active');
			$('.eventwhen').removeClass('active');

			$('.previous_step').addClass('second-d-none');
			$('.col-abc').removeClass('col-abc1');
		}

	});


	$('#right_label').click(function(event) {

		$('#info1').removeClass('d-block');
		$('#info1').addClass('d-none');	
		
		
		$('#info2').removeClass('d-none');
		$('#info2').addClass('d-block');

	});

	$('#left_label').click(function(event) {

		$('#info2').removeClass('d-block');
		$('#info2').addClass('d-none');

		$('#info1').addClass('d-block');
		$('#info1').removeClass('d-none');
	});
	
	$("#q1s").click(function(event) {
		$("#question1").removeClass('display_n')
		$("#question1").addClass('display_b')

		$("#question2").removeClass('display_b')
		$("#question2").addClass('display_n')
	});

	$("#q2s").click(function(event) {
		$("#question2").removeClass('display_n')
		$("#question2").addClass('display_b')

		$("#question1").removeClass('display_b')
		$("#question1").addClass('display_n')
	});

	$('.closes').click(function(event) {
		$(this).parents('.panel').css({
			display: 'none',
		});

		$(this).parent('.accordion').removeClass('btnactive');


	});

	$('.accordion').click(function(event) {
		$(this).toggleClass('btnactive');
	});
});


var acc = document.getElementsByClassName("accordion");

var i;

for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function() {
        this.classList.toggle("active");
       
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
            panel.style.display = "none";
        } else {
            panel.style.display = "block";
        }
    });
}

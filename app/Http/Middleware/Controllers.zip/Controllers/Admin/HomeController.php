<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Post;
use Mail;
use Session;
use App\User;
use App\Admin;
use App\TutorCourse;
use App\TutorExperience;
use App\TutorInfo;
use App\TutorTime;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon ;
use Hash;
class HomeController extends Controller
{

    public function __construct(){
        $this->middleware('auth.admin');
    }
    public function index(){
        $users = DB::table('users')
            ->select('users.*','tutorinfo.*','tutorexperience.*')
            ->join('tutorinfo', 'tutorinfo.user_id', '=', 'users.id') 
            ->join('tutorexperience', 'tutorexperience.user_id', '=','users.id')
            ->orderBy('users.id', 'DESC')
            ->get();
            
        $courses =[];    
        foreach ($users as $value) {
          $data = TutorCourse::where(['user_id' => $value->user_id])->get();
          $singlecourse = [];
          foreach ($data as $val) {
              $singlecourse[] = $val->coursename;
          } 
          $data = implode(",", $singlecourse);
          $courses[] = [
            'user_id' => $value->user_id,
            'firstname' => $value->firstname, 
            'lastname' => $value->lastname, 
            'birthdate' => $value->birthdate, 
            'sex' => $value->sex, 
            'usertype' => $value->tutor_type, 
            'useractive' => $value->useractive, 
            'email' => $value->email, 
            'phone' => $value->phone, 
            'street' => $value->street, 
            'house' => $value->house, 
            'postalcode' => $value->postalcode, 
            'residence' => $value->residence, 
            'experiencewithtutoring' => $value->experiencewithtutoring, 
            'experiencewithadhd' => $value->experiencewithadhd, 
            'experiencewithautisme' => $value->experiencewithautisme, 
            'experiencewithgiftedness' => $value->experiencewithgiftedness, 
            'experiencewithaddpdd' => $value->experiencewithaddpdd, 
            'coursename' => $data
          ];
        }    
        
        $totalTutors = DB::table('users')->count();
        $today = date("Y/m/d");
        $totaltutorlast7days = DB::table('users')->where('created_at', '>=', Carbon::now()->subDays(7))->count();
        return view('admin.home', compact('courses','totalTutors','totaltutorlast7days'));
    }

    public function changeStatus($id){

      $user = User::find($id);
      if($user->useractive == User::ACTIVE){
          $status = User::INACTIVE;
      }else{
        $status = User::ACTIVE;
      }
      $user = new User();
      $user->where(['id' => $id])->update([
              'useractive' => $status
              ]);
      return redirect('/admin');
    }

    public function tutorprofile($id){
        $users = User::find($id);
        $tutorInfo = TutorInfo::where(['user_id' => $id])->first();
        $tutorCourse = TutorCourse::where(['user_id' => $id])->get();
        $tutorExperience = TutorExperience::where(['user_id' => $id])->first();
        $tutorTime = TutorTime::where(['user_id' => $id])->first();
        return view('frontEnd.home.tutorprofile', compact('users','tutorInfo','tutorCourse','tutorExperience','tutorTime'));
    }

    public function changePassForm(){
        return view('admin.changepass');
    }

     public function changepass(Request $request){
        $this->validate($request, [
            'old_password' => 'required',
            'new_password' => 'required|min:8|max:20',
            'confirm_password' => 'required|min:8|max:20|same:new_password',
        ],
        [
          'old_password.required' => 'oud wachtwoord is vereist',
          'new_password.required' => 'nieuw wachtwoord is vereist',
          'new_password.min' => 'nieuw wachtwoord moet meer dan 7 tekens bevatten',
          'new_password.max' => 'nieuw wachtwoord moet minder dan 21 tekens lang zijn',
          'confirm_password.required' => 'bevestig  wachtwoord is vereist',
          'confirm_password.min' => 'bevestig wachtwoord moet meer dan 7 tekens bevatten',
          'confirm_password.max' => 'bevestig wachtwoord moet minder dan 21 tekens lang zijn',
          'confirm_password.same' => 'nieuw wachtwoord en wachtwoord bevestigen is niet correct',
        ]);

        $id = Auth()->guard('admins')->id();
        $newpassword = Hash::make($request['newpassword']);

        $password = Admin::find($id)->password;

        if(Hash::check($request['old_password'], $password))
        { 
            $admin = new Admin();
            $admin->where('id', $id)
            ->update(['password' => $newpassword]);
            return redirect('admin');
        }else{
            Session::flash('mismatch', 'Oud wachtwoord komt niet overeen');
            return redirect('/admin/changepassword');
        }
    }

    public function showEmail(){
      return view('admin.email');
    }
}
